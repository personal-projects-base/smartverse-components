import * as i0 from '@angular/core';
import { InjectionToken, EnvironmentProviders, OnChanges, AfterViewInit, OnDestroy, ElementRef, EventEmitter, SimpleChanges, OnInit, Type } from '@angular/core';
import { DatePipe } from '@angular/common';
import { PaginatorState } from 'primeng/paginator';
import { ConfirmationService, MessageService, MenuItem } from 'primeng/api';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, ControlValueAccessor } from '@angular/forms';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { Menu } from 'primeng/menu';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

interface AccountBalanceItem {
    id: string;
    description: string;
    detail?: string | null;
    balance: number;
    type: 'BANK' | 'CASH';
    open?: boolean;
}
declare class AccountBalancesComponent {
    accounts: AccountBalanceItem[];
    get banks(): AccountBalanceItem[];
    get cashes(): AccountBalanceItem[];
    get total(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountBalancesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountBalancesComponent, "sv-account-balances", never, { "accounts": { "alias": "accounts"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DataTable {
    values: any[];
    fields: Column[];
    totalRecords: number;
    page: number;
    size: number;
    route: string;
    storageKey: string;
    showReports: boolean;
    classBase?: Function;
    filters: Filters[];
    treeValues: any[];
}
declare class Column {
    field: string;
    header: string;
    width: string;
}
declare class Filters {
    field: string;
    key?: string;
    fieldSourceKey?: string;
    defaultValue?: string;
    type: string;
    label: string;
    options?: {
        label: string;
        value: string;
    }[];
    operator?: "eq" | "ge" | "le" | "gte" | "lte" | "nullability";
    route?: string;
    optionLabel?: string;
}

declare class RequestData {
    size?: number;
    offset?: number;
    filter: string;
    order: string;
    displayFields: string;
    append?: boolean;
}

interface SmartverseComponentsConfig {
    translationAssetsPath: string;
    defaultLanguage: string;
    supportedLanguages: Record<string, string>;
    filterStoragePrefix: string;
    endpoints: {
        metadata: string;
        postalCode: string;
        requestUpload: string;
        requestDownload: string;
        deleteObject: string;
        screenReports: string;
        generateScreenReport: string;
    };
}
interface SmartverseComponentsOptions extends Partial<Omit<SmartverseComponentsConfig, 'endpoints' | 'supportedLanguages'>> {
    endpoints?: Partial<SmartverseComponentsConfig['endpoints']>;
    supportedLanguages?: Record<string, string>;
}
declare const DEFAULT_SMARTVERSE_COMPONENTS_CONFIG: SmartverseComponentsConfig;
declare const SMARTVERSE_COMPONENTS_CONFIG: InjectionToken<SmartverseComponentsConfig>;
declare function provideSmartverseComponents(config?: SmartverseComponentsOptions): EnvironmentProviders;

interface TranslationOverride {
    language: string;
    translationKey: string;
    value: string;
}
interface TranslationOverridesLoader {
    load(language: string): Observable<TranslationOverride[]>;
}
declare const SMARTVERSE_TRANSLATION_OVERRIDES: InjectionToken<TranslationOverridesLoader>;
declare class TranslateService {
    private readonly http;
    private readonly platformId;
    private readonly config;
    private readonly overridesLoader;
    private translations;
    private defaults;
    private language;
    constructor(http: HttpClient, platformId: object, config: SmartverseComponentsConfig, overridesLoader: TranslationOverridesLoader | null);
    loadTranslations(): Observable<void>;
    loadTranslationsUser(language: string): Observable<void>;
    loadLanguage(language: string, includeOverrides?: boolean): Observable<void>;
    getDefaultTranslations(language?: string): Observable<Record<string, string>>;
    currentLanguage(): string;
    defaultTranslations(): Record<string, string>;
    translate(key: string): string;
    private resolveLanguage;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateService, [null, null, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateService>;
}

declare enum Action {
    DELETE = 0,
    EDIT = 1,
    ADD = 2
}
declare class DatatableComponent implements OnChanges, AfterViewInit, OnDestroy {
    private confirmationService;
    readonly translateService: TranslateService;
    private datePipe;
    private readonly router;
    private readonly platformId;
    private readonly libraryConfig;
    sidebarVisible: boolean;
    quickSearch: string;
    filterValues: Record<string, any>;
    appliedFilter: string;
    orderField: string;
    orderDirection: 'asc' | 'desc' | '';
    readonly tableStyle: {
        width: string;
        "min-width": string;
    };
    config: DataTable;
    loading: boolean;
    createDisabled: boolean;
    createDisabledReason: string;
    mobileSentinel?: ElementRef<HTMLElement>;
    onRegister: EventEmitter<any>;
    onRefresh: EventEmitter<RequestData>;
    private mobileObserver?;
    private requestingNextPage;
    constructor(confirmationService: ConfirmationService, translateService: TranslateService, datePipe: DatePipe, router: Router, platformId: object, libraryConfig: SmartverseComponentsConfig);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onRowData(row: any, header: string, col: any): any;
    onCustomValue(value: any, col: any): any;
    pageChange($event: PaginatorState): void;
    private loadNextMobilePage;
    onShowFilters(): void;
    onRegisterData(item: any, action: Action): void;
    onRefreshData(): void;
    onApplyFilters(): void;
    onQuickSearch(): void;
    onSort(field: string): void;
    sortIcon(field: string): string;
    isSorted(field: string): boolean;
    private buildFilter;
    private sanitizeFilterValue;
    private filterValue;
    private localDate;
    private initializeFilterDefaults;
    private restoreFilterState;
    private persistFilterState;
    private clearStoredFilterState;
    private filterStorageKey;
    private currentOrder;
    translatedOptions(options?: {
        label: string;
        value: string;
    }[]): {
        label: string;
        value: string;
    }[];
    get reportScreen(): string;
    get reportData(): Record<string, unknown>;
    onDeleteData(item: any, action: Action): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatatableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatatableComponent, "sv-datatable", never, { "config": { "alias": "config"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "createDisabled": { "alias": "createDisabled"; "required": false; }; "createDisabledReason": { "alias": "createDisabledReason"; "required": false; }; }, { "onRegister": "onRegister"; "onRefresh": "onRefresh"; }, never, ["[datatableToolbarAction]"], true, never>;
}

declare class FieldsService {
    private readonly forms;
    private readonly http;
    private readonly config;
    private readonly verifyFieldsValid;
    readonly invokeVerifyValid: Observable<void>;
    constructor(forms: FormBuilder, http: HttpClient, config: SmartverseComponentsConfig);
    verifyIsValid(): void;
    loadForm(_entity: string, service: string): Observable<unknown>;
    createDynamicForm(fields: any[]): FormGroup;
    onCreateFormBuiderDynamic(fields: any[]): FormGroup;
    private createControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FieldsService>;
}

declare abstract class AppControlValueAccessor implements ControlValueAccessor, OnInit, OnDestroy {
    private readonly fields;
    value: any;
    isValid: boolean;
    inputElement?: ElementRef<HTMLElement>;
    focus: boolean;
    disabled: boolean;
    label: string;
    type: string;
    guidance: string;
    field?: FormGroup;
    name: string;
    private readonly destroyed;
    constructor(fields: FieldsService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(disabled: boolean): void;
    onChange: (value: any) => void;
    onTouch: () => void;
    onValid(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppControlValueAccessor, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppControlValueAccessor, never, never, { "focus": { "alias": "focus"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "label": { "alias": "label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "guidance": { "alias": "guidance"; "required": false; }; "field": { "alias": "field"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}

interface PageResponse<T> {
    contents: T[];
    totalRecords?: number;
}
declare class CrudService {
    private readonly http;
    constructor(http: HttpClient);
    save<T>(route: string, body: unknown): Observable<T>;
    update<T>(route: string, id: string | number, body: unknown): Observable<T>;
    delete<T>(route: string, id: string | number): Observable<T>;
    get<T>(route: string, id: string | number): Observable<T>;
    list<T>(route: string, request: RequestData): Observable<PageResponse<T>>;
    onSave<T>(route: string, body: unknown): Observable<T>;
    onUpdate<T>(route: string, id: string | number, body: unknown): Observable<T>;
    onDelete<T>(route: string, id: string | number): Observable<T>;
    onGet<T>(route: string, id: string | number): Observable<T>;
    onGetAll<T>(route: string, request: RequestData): Observable<PageResponse<T>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CrudService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CrudService>;
}

declare class AutoCompleteComponent extends AppControlValueAccessor {
    private readonly fieldServiceInputText;
    private readonly crudService;
    private autoComplete?;
    optionLabel: string;
    route: string;
    defaultFilter: string;
    onSelectChange: EventEmitter<void>;
    itens: any[];
    constructor(fieldServiceInputText: FieldsService, crudService: CrudService);
    writeValue(value: any): void;
    onFilter(value: any): void;
    onRequestData(value: any): RequestData;
    onSelected(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoCompleteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AutoCompleteComponent, "sv-auto-complete", never, { "optionLabel": { "alias": "optionLabel"; "required": false; }; "route": { "alias": "route"; "required": false; }; "defaultFilter": { "alias": "defaultFilter"; "required": false; }; }, { "onSelectChange": "onSelectChange"; }, never, never, true, never>;
}

declare class DropdownComponent extends AppControlValueAccessor {
    private readonly fieldServiceInputText;
    options: any[];
    optionLabel: string;
    optionValue: string;
    constructor(fieldServiceInputText: FieldsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent, "sv-dropdown", never, { "options": { "alias": "options"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "optionValue": { "alias": "optionValue"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ImageUploadService {
    private readonly http;
    private readonly config;
    constructor(http: HttpClient, config: SmartverseComponentsConfig);
    onRequestUpload(imageName: string): Observable<any>;
    onRequestDonwload(imageName: string): Observable<any>;
    onDeleteObject(imageName: string): Observable<any>;
    onUpload(url: string, file: ArrayBuffer): Observable<any>;
    private params;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageUploadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ImageUploadService>;
}

interface ToastMessage {
    summary: string;
    detail: string;
}
declare class ToastService {
    private readonly messages;
    constructor(messages: MessageService);
    success(message: ToastMessage): void;
    warn(message: ToastMessage): void;
    info(message: ToastMessage): void;
    error(message: ToastMessage): void;
    private add;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToastService>;
}

declare class ImageUploadComponent extends AppControlValueAccessor {
    private readonly imageUploadService;
    private readonly toastService;
    private readonly fieldServiceInputText;
    _image: File | null;
    imageUrl: string | null;
    tokenImageUrl: string;
    ownerId: string;
    cropAspectRatio?: number;
    cropResizeWidth: number;
    eventLoading: EventEmitter<void>;
    eventImageToken: EventEmitter<string>;
    imageChangedEvent: Event | null;
    croppedImage: Blob | null;
    cropVisible: boolean;
    constructor(imageUploadService: ImageUploadService, toastService: ToastService, fieldServiceInputText: FieldsService);
    onFileInput(fileInput?: HTMLInputElement): void;
    onImageSelect(event: any): void;
    onImageCropped(event: ImageCroppedEvent): void;
    cancelCrop(fileInput?: HTMLInputElement): void;
    confirmCrop(fileInput?: HTMLInputElement): Promise<void>;
    private imageExtension;
    private onSendAws;
    private onRequestDonwload;
    onDeleteImage(): void;
    onShowLoading(): void;
    onImageToken(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageUploadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageUploadComponent, "sv-image-upload", never, { "imageUrl": { "alias": "imageUrl"; "required": false; }; "tokenImageUrl": { "alias": "tokenImageUrl"; "required": false; }; "ownerId": { "alias": "ownerId"; "required": false; }; "cropAspectRatio": { "alias": "cropAspectRatio"; "required": false; }; "cropResizeWidth": { "alias": "cropResizeWidth"; "required": false; }; }, { "eventLoading": "eventLoading"; "eventImageToken": "eventImageToken"; }, never, never, true, never>;
}

declare class InputDateComponent extends AppControlValueAccessor {
    private readonly fieldServiceInputText;
    showTime: boolean;
    constructor(fieldServiceInputText: FieldsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<InputDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputDateComponent, "sv-input-date", never, { "showTime": { "alias": "showTime"; "required": false; }; }, {}, never, never, true, never>;
}

declare class InputMaskComponent extends AppControlValueAccessor {
    private readonly fieldServiceInputText;
    mask: string;
    blurred: EventEmitter<void>;
    constructor(fieldServiceInputText: FieldsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<InputMaskComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputMaskComponent, "sv-input-mask", never, { "mask": { "alias": "mask"; "required": false; }; }, { "blurred": "blurred"; }, never, never, true, never>;
}

declare class InputNumberComponent extends AppControlValueAccessor {
    static ɵfac: i0.ɵɵFactoryDeclaration<InputNumberComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputNumberComponent, "sv-input-number", never, {}, {}, never, never, true, never>;
}

declare class InputTextComponent extends AppControlValueAccessor {
    private readonly fieldServiceInputText;
    fieldType: string;
    constructor(fieldServiceInputText: FieldsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<InputTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputTextComponent, "sv-input-text", never, { "fieldType": { "alias": "fieldType"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MultiSelectComponent extends AppControlValueAccessor implements OnInit {
    private readonly crud;
    options: any[];
    optionLabel: string;
    dataKey: string;
    route: string;
    defaultFilter: string;
    filter: boolean;
    display: 'comma' | 'chip';
    pageSize: number;
    constructor(fields: FieldsService, crud: CrudService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiSelectComponent, "sv-multi-select", never, { "options": { "alias": "options"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "dataKey": { "alias": "dataKey"; "required": false; }; "route": { "alias": "route"; "required": false; }; "defaultFilter": { "alias": "defaultFilter"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "display": { "alias": "display"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, {}, never, never, true, never>;
}

declare class LoadingComponent {
    showLoading: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingComponent, "sv-loading", never, { "showLoading": { "alias": "showLoading"; "required": false; }; }, {}, never, never, true, never>;
}

interface MobileTreeAction {
    data: any;
    action: 'add' | 'edit' | 'delete';
}
declare class MobileTreeListComponent implements AfterViewInit, OnChanges, OnDestroy {
    translateService: TranslateService;
    private platformId;
    nodes: any[];
    fields: Column[];
    loading: boolean;
    hasMore: boolean;
    loadMore: EventEmitter<void>;
    treeAction: EventEmitter<MobileTreeAction>;
    sentinel?: ElementRef<HTMLElement>;
    private expanded;
    private observer?;
    private requesting;
    constructor(translateService: TranslateService, platformId: object);
    get visibleRows(): any[];
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    toggle(n: any): void;
    isExpanded(n: any): boolean;
    hasChildren(n: any): boolean;
    value(d: any, f: string): any;
    emit(data: any, action: MobileTreeAction['action']): void;
    private requestNext;
    private flatten;
    private key;
    static ɵfac: i0.ɵɵFactoryDeclaration<MobileTreeListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MobileTreeListComponent, "sv-mobile-tree-list", never, { "nodes": { "alias": "nodes"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "hasMore": { "alias": "hasMore"; "required": false; }; }, { "loadMore": "loadMore"; "treeAction": "treeAction"; }, never, never, true, never>;
}

interface ScreenReportOption {
    id: string;
    name: string;
}
interface ScreenReportsResponse {
    reports: ScreenReportOption[];
}
interface GenerateScreenReportRequest {
    reportId: string;
    data: Record<string, unknown>;
}
interface GenerateScreenReportResponse {
    report: string;
}

declare class ScreenReportService {
    private readonly http;
    private readonly config;
    constructor(http: HttpClient, config: SmartverseComponentsConfig);
    getByScreen(screen: string): Observable<ScreenReportsResponse>;
    generate(request: GenerateScreenReportRequest): Observable<GenerateScreenReportResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScreenReportService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScreenReportService>;
}

declare class ScreenReportButtonComponent implements OnChanges, OnDestroy {
    private readonly reportsService;
    private readonly toast;
    readonly translate: TranslateService;
    private readonly platformId;
    screen: string;
    data: Record<string, unknown>;
    disabled: boolean;
    outlined: boolean;
    reports: ScreenReportOption[];
    menuItems: MenuItem[];
    loading: boolean;
    private loadSubscription?;
    private generateSubscription?;
    constructor(reportsService: ScreenReportService, toast: ToastService, translate: TranslateService, platformId: object);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    open(event: Event, menu: Menu): void;
    private loadReports;
    private generate;
    private createPdfUrl;
    private openFallback;
    private normalizeScreen;
    private showError;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScreenReportButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScreenReportButtonComponent, "sv-screen-report-button", never, { "screen": { "alias": "screen"; "required": true; }; "data": { "alias": "data"; "required": true; }; "disabled": { "alias": "disabled"; "required": false; }; "outlined": { "alias": "outlined"; "required": false; }; }, {}, never, never, true, never>;
}

interface SidebarMenuItem {
    id: string;
    label: string;
    icon?: string;
    route?: string | any[];
    badge?: string | number;
    disabled?: boolean;
    visible?: boolean;
    children?: SidebarMenuItem[];
}
interface SidebarUser {
    name: string;
    subtitle?: string;
    imageUrl?: string | null;
    initials?: string;
}

declare class SidebarComponent {
    private readonly platformId;
    brand: string;
    logoUrl?: string;
    items: SidebarMenuItem[];
    user?: SidebarUser;
    logoutLabel: string;
    showLogout: boolean;
    expanded: boolean;
    readonly expandedChange: EventEmitter<boolean>;
    readonly itemSelected: EventEmitter<SidebarMenuItem>;
    readonly logout: EventEmitter<void>;
    mobile: boolean;
    constructor(platformId: object);
    updateViewport(): void;
    toggle(): void;
    select(item: SidebarMenuItem): void;
    private setExpanded;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarComponent, "sv-sidebar", never, { "brand": { "alias": "brand"; "required": false; }; "logoUrl": { "alias": "logoUrl"; "required": false; }; "items": { "alias": "items"; "required": false; }; "user": { "alias": "user"; "required": false; }; "logoutLabel": { "alias": "logoutLabel"; "required": false; }; "showLogout": { "alias": "showLogout"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "expandedChange": "expandedChange"; "itemSelected": "itemSelected"; "logout": "logout"; }, never, ["[sidebar-footer]"], true, never>;
}

declare class SmartverseComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartverseComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SmartverseComponentsModule, never, [typeof AccountBalancesComponent, typeof DatatableComponent, typeof AutoCompleteComponent, typeof DropdownComponent, typeof ImageUploadComponent, typeof InputDateComponent, typeof InputMaskComponent, typeof InputNumberComponent, typeof InputTextComponent, typeof MultiSelectComponent, typeof LoadingComponent, typeof MobileTreeListComponent, typeof ScreenReportButtonComponent, typeof SidebarComponent], [typeof AccountBalancesComponent, typeof DatatableComponent, typeof AutoCompleteComponent, typeof DropdownComponent, typeof ImageUploadComponent, typeof InputDateComponent, typeof InputMaskComponent, typeof InputNumberComponent, typeof InputTextComponent, typeof MultiSelectComponent, typeof LoadingComponent, typeof MobileTreeListComponent, typeof ScreenReportButtonComponent, typeof SidebarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SmartverseComponentsModule>;
}

declare class BaseComponent {
    showLoading: boolean;
    onShowLoading(): void;
    onValidator(form: FormGroup): boolean;
}

declare class Fields {
    name: string;
    label: String;
    type?: string;
    size: number;
    hidden?: boolean;
    order: number;
    guidance?: string;
    validators?: any[];
    required?: boolean;
    /**
     * Propriedade para definir se o campo será visivel e dispoibiliczado para filtragem dos dados
     */
    enableFieldsFilter?: boolean;
    reference?: any;
}

declare class FieldsForm {
    /**
     * Campos do formulario, não é necessário preencher, será preenchido automaticamente
     */
    fields?: Fields[];
    /**
     * Form Group, não é necessário preencher
     */
    formgroup?: FormGroup;
}

declare class SidebarSubmenuComponent {
    items: SidebarMenuItem[];
    readonly itemSelected: EventEmitter<SidebarMenuItem>;
    readonly expanded: Set<string>;
    get visibleItems(): SidebarMenuItem[];
    toggle(id: string): void;
    select(event: Event, item: SidebarMenuItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarSubmenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarSubmenuComponent, "sv-sidebar-submenu", never, { "items": { "alias": "items"; "required": false; }; }, { "itemSelected": "itemSelected"; }, never, never, true, never>;
}

interface PostalCodeAddress {
    postalCode: string;
    address: string;
    neighborhood: string;
    complement: string;
    city: unknown;
}
declare class PostalCodeService {
    private readonly http;
    private readonly config;
    constructor(http: HttpClient, config: SmartverseComponentsConfig);
    lookup(postalCode: string): Observable<PostalCodeAddress>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PostalCodeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PostalCodeService>;
}

interface ModalConfig<T = unknown> {
    component: Type<unknown>;
    data?: T;
    header?: string;
    width?: string;
}
declare class ModalService {
    private readonly dialogs;
    constructor(dialogs: DialogService);
    open<T, R = unknown>(config: ModalConfig<T>): DynamicDialogRef<R> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModalService>;
}

declare class ThemeService {
    private readonly document;
    constructor(document: Document);
    setDarkMode(enabled: boolean): void;
    onConfigurationTheme(theme: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeService>;
}

declare function generateUUIDv4(): string;
declare function base64ToArrayBuffer(base64: string): ArrayBuffer;

declare function getNextTreeCode(items: any[], parentCode?: string | null): string;

export { AccountBalancesComponent, Action, AppControlValueAccessor, AutoCompleteComponent, BaseComponent, Column, CrudService, DEFAULT_SMARTVERSE_COMPONENTS_CONFIG, DataTable, DatatableComponent, DropdownComponent, Fields, FieldsForm, FieldsService, Filters, ImageUploadComponent, ImageUploadService, InputDateComponent, InputMaskComponent, InputNumberComponent, InputTextComponent, LoadingComponent, MobileTreeListComponent, ModalService, MultiSelectComponent, PostalCodeService, RequestData, SMARTVERSE_COMPONENTS_CONFIG, SMARTVERSE_TRANSLATION_OVERRIDES, ScreenReportButtonComponent, ScreenReportService, SidebarComponent, SidebarSubmenuComponent, SmartverseComponentsModule, ThemeService, ToastService, TranslateService, base64ToArrayBuffer, generateUUIDv4, getNextTreeCode, provideSmartverseComponents };
export type { AccountBalanceItem, GenerateScreenReportRequest, GenerateScreenReportResponse, MobileTreeAction, ModalConfig, PageResponse, PostalCodeAddress, ScreenReportOption, ScreenReportsResponse, SidebarMenuItem, SidebarUser, SmartverseComponentsConfig, SmartverseComponentsOptions, ToastMessage, TranslationOverride, TranslationOverridesLoader };
