import * as i0 from '@angular/core';
import { Input, Component, InjectionToken, makeEnvironmentProviders, Inject, Injectable, PLATFORM_ID, Optional, ViewChild, Directive, EventEmitter, Output, HostListener, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, isPlatformBrowser, DatePipe, DOCUMENT } from '@angular/common';
import * as i4 from 'primeng/button';
import { ButtonModule } from 'primeng/button';
import * as i6$1 from 'primeng/table';
import { TableModule } from 'primeng/table';
import * as i7 from 'primeng/drawer';
import { DrawerModule } from 'primeng/drawer';
import * as i8 from 'primeng/iconfield';
import { IconFieldModule } from 'primeng/iconfield';
import * as i9 from 'primeng/inputicon';
import { InputIconModule } from 'primeng/inputicon';
import * as i10 from 'primeng/inputtext';
import { InputTextModule } from 'primeng/inputtext';
import * as i11 from 'primeng/paginator';
import { PaginatorModule } from 'primeng/paginator';
import * as i12 from 'primeng/confirmdialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import * as i1$2 from 'primeng/api';
import { MessageService, ConfirmationService } from 'primeng/api';
import * as i4$1 from '@angular/forms';
import { Validators, FormControl, FormsModule, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i3$1 from 'primeng/select';
import { SelectModule } from 'primeng/select';
import * as i6$2 from 'primeng/tooltip';
import { TooltipModule } from 'primeng/tooltip';
import * as i5 from 'primeng/menu';
import { MenuModule } from 'primeng/menu';
import * as i1$1 from '@angular/common/http';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import * as i1$4 from 'primeng/dynamicdialog';
import { DialogService } from 'primeng/dynamicdialog';
import { switchMap, of, map, Subject, takeUntil } from 'rxjs';
import * as i5$1 from 'primeng/floatlabel';
import { FloatLabelModule } from 'primeng/floatlabel';
import * as i3 from 'primeng/datepicker';
import { DatePickerModule } from 'primeng/datepicker';
import * as i6 from 'primeng/autofocus';
import { AutoFocusModule } from 'primeng/autofocus';
import * as i4$2 from 'primeng/autocomplete';
import { AutoCompleteModule, AutoComplete } from 'primeng/autocomplete';
import * as i4$3 from '@angular/router';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Ripple } from 'primeng/ripple';
import { ImageCropperComponent } from 'ngx-image-cropper';
import * as i3$2 from 'primeng/inputmask';
import { InputMaskModule } from 'primeng/inputmask';
import * as i5$2 from 'primeng/inputnumber';
import { InputNumberModule } from 'primeng/inputnumber';
import * as i7$1 from 'primeng/textarea';
import { TextareaModule } from 'primeng/textarea';
import * as i6$3 from 'primeng/multiselect';
import { MultiSelectModule } from 'primeng/multiselect';
import * as i1$3 from 'primeng/avatar';
import { AvatarModule } from 'primeng/avatar';

class AccountBalancesComponent {
    accounts = [];
    get banks() { return this.accounts.filter(item => item.type === 'BANK'); }
    get cashes() { return this.accounts.filter(item => item.type === 'CASH'); }
    get total() { return this.accounts.reduce((sum, item) => sum + item.balance, 0); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AccountBalancesComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AccountBalancesComponent, isStandalone: true, selector: "sv-account-balances", inputs: { accounts: "accounts" }, ngImport: i0, template: "<article class=\"balances-card\">\n  <div class=\"title\"><div><span>Disponibilidade</span><h2>Contas e caixas</h2></div><strong>{{ total | currency:'BRL' }}</strong></div>\n  <div class=\"accounts-scroll\">\n    <h3><i class=\"pi pi-building-columns\"></i> Contas banc\u00E1rias</h3>\n    <p class=\"empty\" *ngIf=\"!banks.length\">Nenhuma conta considerada.</p>\n    <div class=\"row\" *ngFor=\"let item of banks\">\n      <div><b>{{ item.description }}</b><small>{{ item.detail || 'Conta n\u00E3o informada' }}</small></div>\n      <strong>{{ item.balance | currency:'BRL' }}</strong>\n    </div>\n    <h3><i class=\"pi pi-inbox\"></i> Caixas</h3>\n    <p class=\"empty\" *ngIf=\"!cashes.length\">Nenhum caixa considerado.</p>\n    <div class=\"row\" *ngFor=\"let item of cashes\">\n      <div><b>{{ item.description }} <span class=\"status\" [class.open]=\"item.open\">{{ item.open ? 'ABERTO' : 'FECHADO' }}</span></b><small>{{ item.detail }}</small></div>\n      <strong>{{ item.balance | currency:'BRL' }}</strong>\n    </div>\n  </div>\n</article>\n", styles: [":host{display:block;min-width:0}.balances-card{background:var(--p-content-background);border:1px solid var(--p-content-border-color);border-radius:12px;padding:1rem;height:100%}.title{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:.35rem}.title span{color:var(--p-text-muted-color);font-size:.75rem;text-transform:uppercase;letter-spacing:.08em}.title h2{margin:.2rem 0 0}.title>strong{font-size:1.25rem;color:var(--p-primary-color)}.accounts-scroll{max-height:27rem;overflow-y:auto;overscroll-behavior:contain;padding-right:.45rem;scrollbar-gutter:stable}.accounts-scroll::-webkit-scrollbar{width:.45rem}.accounts-scroll::-webkit-scrollbar-thumb{background:var(--p-content-border-color);border-radius:99px}.accounts-scroll::-webkit-scrollbar-track{background:transparent}h3{font-size:.9rem;margin:1rem 0 .4rem;display:flex;gap:.5rem;align-items:center}.row{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.7rem 0;border-bottom:1px solid var(--p-content-border-color)}.row div{display:flex;flex-direction:column;min-width:0}.row small,.empty{color:var(--p-text-muted-color)}.status{font-size:.65rem;border-radius:99px;padding:.15rem .4rem;background:color-mix(in srgb,#ef4444,transparent 86%);color:#dc2626}.status.open{background:color-mix(in srgb,#22c55e,transparent 86%);color:#16a34a}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.CurrencyPipe, name: "currency" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AccountBalancesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-account-balances', imports: [CommonModule], template: "<article class=\"balances-card\">\n  <div class=\"title\"><div><span>Disponibilidade</span><h2>Contas e caixas</h2></div><strong>{{ total | currency:'BRL' }}</strong></div>\n  <div class=\"accounts-scroll\">\n    <h3><i class=\"pi pi-building-columns\"></i> Contas banc\u00E1rias</h3>\n    <p class=\"empty\" *ngIf=\"!banks.length\">Nenhuma conta considerada.</p>\n    <div class=\"row\" *ngFor=\"let item of banks\">\n      <div><b>{{ item.description }}</b><small>{{ item.detail || 'Conta n\u00E3o informada' }}</small></div>\n      <strong>{{ item.balance | currency:'BRL' }}</strong>\n    </div>\n    <h3><i class=\"pi pi-inbox\"></i> Caixas</h3>\n    <p class=\"empty\" *ngIf=\"!cashes.length\">Nenhum caixa considerado.</p>\n    <div class=\"row\" *ngFor=\"let item of cashes\">\n      <div><b>{{ item.description }} <span class=\"status\" [class.open]=\"item.open\">{{ item.open ? 'ABERTO' : 'FECHADO' }}</span></b><small>{{ item.detail }}</small></div>\n      <strong>{{ item.balance | currency:'BRL' }}</strong>\n    </div>\n  </div>\n</article>\n", styles: [":host{display:block;min-width:0}.balances-card{background:var(--p-content-background);border:1px solid var(--p-content-border-color);border-radius:12px;padding:1rem;height:100%}.title{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:.35rem}.title span{color:var(--p-text-muted-color);font-size:.75rem;text-transform:uppercase;letter-spacing:.08em}.title h2{margin:.2rem 0 0}.title>strong{font-size:1.25rem;color:var(--p-primary-color)}.accounts-scroll{max-height:27rem;overflow-y:auto;overscroll-behavior:contain;padding-right:.45rem;scrollbar-gutter:stable}.accounts-scroll::-webkit-scrollbar{width:.45rem}.accounts-scroll::-webkit-scrollbar-thumb{background:var(--p-content-border-color);border-radius:99px}.accounts-scroll::-webkit-scrollbar-track{background:transparent}h3{font-size:.9rem;margin:1rem 0 .4rem;display:flex;gap:.5rem;align-items:center}.row{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.7rem 0;border-bottom:1px solid var(--p-content-border-color)}.row div{display:flex;flex-direction:column;min-width:0}.row small,.empty{color:var(--p-text-muted-color)}.status{font-size:.65rem;border-radius:99px;padding:.15rem .4rem;background:color-mix(in srgb,#ef4444,transparent 86%);color:#dc2626}.status.open{background:color-mix(in srgb,#22c55e,transparent 86%);color:#16a34a}\n"] }]
        }], propDecorators: { accounts: [{
                type: Input
            }] } });

class DataTable {
    values = [];
    fields = [];
    totalRecords = 0;
    page = 1;
    size = 10;
    route = "";
    storageKey = "";
    showReports = false;
    classBase;
    filters = [];
    treeValues = [];
}
class Column {
    field = "";
    header = "";
    width = "";
}
class Filters {
    field = "";
    key;
    fieldSourceKey;
    defaultValue;
    type = "string";
    label = "";
    options;
    operator;
    route;
    optionLabel;
}

class RequestData {
    size = 10;
    offset = 0;
    filter = "";
    order = "";
    displayFields = "*";
    append = false;
}

const DEFAULT_SMARTVERSE_COMPONENTS_CONFIG = {
    translationAssetsPath: '/assets/i18n',
    defaultLanguage: 'pt-BR',
    supportedLanguages: {
        PORTUGUESE: 'pt-BR',
        ENGLISH: 'en-US',
        SPANISH: 'es-ES',
    },
    filterStoragePrefix: 'smartverse:datatable-filters',
    endpoints: {
        metadata: 'anonymous/rest/{service}/metadata',
        postalCode: 'lookupPostalCode',
        requestUpload: 'requestUpload',
        requestDownload: 'requestUrl',
        deleteObject: 'deleteObject',
        screenReports: 'getScreenReports',
        generateScreenReport: 'generateScreenReport',
    },
};
const SMARTVERSE_COMPONENTS_CONFIG = new InjectionToken('SMARTVERSE_COMPONENTS_CONFIG', { providedIn: 'root', factory: () => DEFAULT_SMARTVERSE_COMPONENTS_CONFIG });
function provideSmartverseComponents(config = {}) {
    const value = {
        ...DEFAULT_SMARTVERSE_COMPONENTS_CONFIG,
        ...config,
        supportedLanguages: {
            ...DEFAULT_SMARTVERSE_COMPONENTS_CONFIG.supportedLanguages,
            ...config.supportedLanguages,
        },
        endpoints: {
            ...DEFAULT_SMARTVERSE_COMPONENTS_CONFIG.endpoints,
            ...config.endpoints,
        },
    };
    return makeEnvironmentProviders([
        { provide: SMARTVERSE_COMPONENTS_CONFIG, useValue: value },
        MessageService,
        DialogService,
    ]);
}

class ScreenReportService {
    http;
    config;
    constructor(http, config) {
        this.http = http;
        this.config = config;
    }
    getByScreen(screen) {
        return this.http.get(this.config.endpoints.screenReports, { params: new HttpParams().set('screen', screen) });
    }
    generate(request) {
        return this.http.post(this.config.endpoints.generateScreenReport, request);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ScreenReportService, deps: [{ token: i1$1.HttpClient }, { token: SMARTVERSE_COMPONENTS_CONFIG }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ScreenReportService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ScreenReportService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SMARTVERSE_COMPONENTS_CONFIG]
                }] }] });

class ToastService {
    messages;
    constructor(messages) {
        this.messages = messages;
    }
    success(message) { this.add('success', message); }
    warn(message) { this.add('warn', message); }
    info(message) { this.add('info', message); }
    error(message) { this.add('error', message); }
    add(severity, message) { this.messages.add({ severity, ...message }); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ToastService, deps: [{ token: i1$2.MessageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$2.MessageService }] });

const SMARTVERSE_TRANSLATION_OVERRIDES = new InjectionToken('SMARTVERSE_TRANSLATION_OVERRIDES');
class TranslateService {
    http;
    platformId;
    config;
    overridesLoader;
    translations = {};
    defaults = {};
    language;
    constructor(http, platformId, config, overridesLoader) {
        this.http = http;
        this.platformId = platformId;
        this.config = config;
        this.overridesLoader = overridesLoader;
        this.language = config.defaultLanguage;
    }
    loadTranslations() {
        if (isPlatformBrowser(this.platformId)) {
            const browserLanguage = navigator.language ?? this.config.defaultLanguage;
            this.language = this.resolveLanguage(browserLanguage);
        }
        return this.loadLanguage(this.language);
    }
    loadTranslationsUser(language) {
        return this.loadLanguage(this.resolveLanguage(language));
    }
    loadLanguage(language, includeOverrides = true) {
        this.language = this.resolveLanguage(language);
        return this.getDefaultTranslations(this.language).pipe(switchMap(defaults => {
            this.defaults = defaults;
            this.translations = { ...defaults };
            if (!includeOverrides || !this.overridesLoader)
                return of(void 0);
            return this.overridesLoader.load(this.language).pipe(map(overrides => {
                for (const override of overrides) {
                    this.translations[override.translationKey] = override.value;
                }
            }));
        }));
    }
    getDefaultTranslations(language = this.language) {
        const base = this.config.translationAssetsPath.replace(/\/$/, '');
        return this.http.get(`${base}/${this.resolveLanguage(language)}.json`);
    }
    currentLanguage() { return this.language; }
    defaultTranslations() { return { ...this.defaults }; }
    translate(key) { return this.translations[key] ?? key; }
    resolveLanguage(language) {
        const mapped = this.config.supportedLanguages[language];
        if (mapped)
            return mapped;
        if (language.toLowerCase().startsWith('en'))
            return 'en-US';
        if (language.toLowerCase().startsWith('es'))
            return 'es-ES';
        if (language.toLowerCase().startsWith('pt'))
            return 'pt-BR';
        return this.config.defaultLanguage;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: TranslateService, deps: [{ token: i1$1.HttpClient }, { token: PLATFORM_ID }, { token: SMARTVERSE_COMPONENTS_CONFIG }, { token: SMARTVERSE_TRANSLATION_OVERRIDES, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: TranslateService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: TranslateService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SMARTVERSE_COMPONENTS_CONFIG]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SMARTVERSE_TRANSLATION_OVERRIDES]
                }] }] });

class ScreenReportButtonComponent {
    reportsService;
    toast;
    translate;
    platformId;
    screen = '';
    data = {};
    disabled = false;
    outlined = true;
    reports = [];
    menuItems = [];
    loading = false;
    loadSubscription;
    generateSubscription;
    constructor(reportsService, toast, translate, platformId) {
        this.reportsService = reportsService;
        this.toast = toast;
        this.translate = translate;
        this.platformId = platformId;
    }
    ngOnChanges(changes) {
        if (changes['screen'])
            this.loadReports();
    }
    ngOnDestroy() {
        this.loadSubscription?.unsubscribe();
        this.generateSubscription?.unsubscribe();
    }
    open(event, menu) {
        if (this.disabled || this.loading || !this.reports.length)
            return;
        if (this.reports.length === 1) {
            this.generate(this.reports[0]);
            return;
        }
        menu.toggle(event);
    }
    loadReports() {
        this.loadSubscription?.unsubscribe();
        this.reports = [];
        this.menuItems = [];
        const normalizedScreen = this.normalizeScreen(this.screen);
        if (!normalizedScreen)
            return;
        this.loadSubscription = this.reportsService.getByScreen(normalizedScreen).subscribe({
            next: response => {
                this.reports = response.reports ?? [];
                this.menuItems = this.reports.map(report => ({
                    label: report.name,
                    icon: 'pi pi-file-pdf',
                    command: () => this.generate(report),
                }));
            },
            error: () => {
                this.reports = [];
                this.menuItems = [];
            },
        });
    }
    generate(report) {
        if (!isPlatformBrowser(this.platformId))
            return;
        const preview = window.open('', '_blank');
        this.loading = true;
        this.generateSubscription?.unsubscribe();
        this.generateSubscription = this.reportsService.generate({
            reportId: report.id,
            data: this.data,
        }).subscribe({
            next: response => {
                this.loading = false;
                try {
                    const url = this.createPdfUrl(response.report);
                    if (preview)
                        preview.location.href = url;
                    else
                        this.openFallback(url);
                    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
                }
                catch {
                    preview?.close();
                    this.showError('screen_report_invalid_pdf');
                }
            },
            error: error => {
                this.loading = false;
                preview?.close();
                this.showError(error?.error?.message ?? 'screen_report_generation_error');
            },
        });
    }
    createPdfUrl(base64) {
        if (!base64)
            throw new Error('empty_pdf');
        const binary = window.atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let index = 0; index < binary.length; index++) {
            bytes[index] = binary.charCodeAt(index);
        }
        return URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
    }
    openFallback(url) {
        const link = document.createElement('a');
        link.href = url;
        link.target = '_blank';
        link.rel = 'noopener';
        link.click();
    }
    normalizeScreen(screen) {
        const path = screen.split('?')[0].trim();
        if (!path)
            return '';
        return path.length > 1 ? path.replace(/\/+$/, '') : path;
    }
    showError(message) {
        this.toast.error({
            summary: this.translate.translate('common_message'),
            detail: this.translate.translate(message),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ScreenReportButtonComponent, deps: [{ token: ScreenReportService }, { token: ToastService }, { token: TranslateService }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: ScreenReportButtonComponent, isStandalone: true, selector: "sv-screen-report-button", inputs: { screen: "screen", data: "data", disabled: "disabled", outlined: "outlined" }, usesOnChanges: true, ngImport: i0, template: "@if (reports.length) {\n  <p-menu #reportMenu [model]=\"menuItems\" [popup]=\"true\" appendTo=\"body\" />\n  <p-button\n    type=\"button\"\n    icon=\"pi pi-print\"\n    [outlined]=\"outlined\"\n    [loading]=\"loading\"\n    [disabled]=\"disabled\"\n    [label]=\"translate.translate(reports.length > 1 ? 'screen_reports' : 'common_print')\"\n    (onClick)=\"open($event, reportMenu)\" />\n}\n", styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i4.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: MenuModule }, { kind: "component", type: i5.Menu, selector: "p-menu", inputs: ["model", "popup", "style", "styleClass", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "ariaLabel", "ariaLabelledBy", "id", "tabindex", "appendTo", "motionOptions"], outputs: ["onShow", "onHide", "onBlur", "onFocus"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ScreenReportButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-screen-report-button', imports: [ButtonModule, MenuModule], template: "@if (reports.length) {\n  <p-menu #reportMenu [model]=\"menuItems\" [popup]=\"true\" appendTo=\"body\" />\n  <p-button\n    type=\"button\"\n    icon=\"pi pi-print\"\n    [outlined]=\"outlined\"\n    [loading]=\"loading\"\n    [disabled]=\"disabled\"\n    [label]=\"translate.translate(reports.length > 1 ? 'screen_reports' : 'common_print')\"\n    (onClick)=\"open($event, reportMenu)\" />\n}\n", styles: [":host{display:inline-flex}\n"] }]
        }], ctorParameters: () => [{ type: ScreenReportService }, { type: ToastService }, { type: TranslateService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { screen: [{
                type: Input,
                args: [{ required: true }]
            }], data: [{
                type: Input,
                args: [{ required: true }]
            }], disabled: [{
                type: Input
            }], outlined: [{
                type: Input
            }] } });

class FieldsService {
    forms;
    http;
    config;
    verifyFieldsValid = new Subject();
    invokeVerifyValid = this.verifyFieldsValid.asObservable();
    constructor(forms, http, config) {
        this.forms = forms;
        this.http = http;
        this.config = config;
    }
    verifyIsValid() { this.verifyFieldsValid.next(); }
    loadForm(_entity, service) {
        const endpoint = this.config.endpoints.metadata.replace('{service}', service);
        return this.http.post(endpoint, { metadata: 'FIELDS' });
    }
    createDynamicForm(fields) {
        const form = this.forms.group({});
        for (const field of fields) {
            form.addControl(field.fieldName, field.type === 'object' ? this.createDynamicForm(field.fields) : this.createControl(field));
        }
        return form;
    }
    onCreateFormBuiderDynamic(fields) { return this.createDynamicForm(fields); }
    createControl(field) {
        const validators = [];
        if (field.required && !field.hidden)
            validators.push(Validators.required);
        if (field.type === 'email')
            validators.push(Validators.email);
        return new FormControl(null, validators);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FieldsService, deps: [{ token: i4$1.FormBuilder }, { token: i1$1.HttpClient }, { token: SMARTVERSE_COMPONENTS_CONFIG }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FieldsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FieldsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i4$1.FormBuilder }, { type: i1$1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SMARTVERSE_COMPONENTS_CONFIG]
                }] }] });

class AppControlValueAccessor {
    fields;
    value = null;
    isValid = true;
    inputElement;
    focus = false;
    disabled = false;
    label = '';
    type = '';
    guidance = '';
    field;
    name = '';
    destroyed = new Subject();
    constructor(fields) {
        this.fields = fields;
    }
    ngOnInit() { this.fields.invokeVerifyValid.pipe(takeUntil(this.destroyed)).subscribe(() => this.onValid()); }
    ngOnDestroy() { this.destroyed.next(); this.destroyed.complete(); }
    writeValue(value) { this.value = value === '' ? null : value; }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouch = fn; }
    setDisabledState(disabled) { this.disabled = disabled; }
    onChange = (value) => { this.value = value === '' ? null : value; };
    onTouch = () => undefined;
    onValid() { this.isValid = this.field?.get(this.name)?.valid ?? true; }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AppControlValueAccessor, deps: [{ token: FieldsService }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: AppControlValueAccessor, isStandalone: true, inputs: { focus: "focus", disabled: "disabled", label: "label", type: "type", guidance: "guidance", field: "field", name: "name" }, viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AppControlValueAccessor, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: FieldsService }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], focus: [{
                type: Input
            }], disabled: [{
                type: Input
            }], label: [{
                type: Input
            }], type: [{
                type: Input
            }], guidance: [{
                type: Input
            }], field: [{
                type: Input
            }], name: [{
                type: Input
            }] } });

class InputDateComponent extends AppControlValueAccessor {
    fieldServiceInputText;
    showTime = false;
    constructor(fieldServiceInputText) {
        super(fieldServiceInputText);
        this.fieldServiceInputText = fieldServiceInputText;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputDateComponent, deps: [{ token: FieldsService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: InputDateComponent, isStandalone: true, selector: "sv-input-date", inputs: { showTime: "showTime" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: InputDateComponent,
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "<p-floatLabel>\n  <p-datepicker\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n    [iconDisplay]=\"'input'\"\n    [showIcon]=\"true\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    appendTo=\"body\"\n      [pAutoFocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [touchUI]=\"false\"\n    [showTime]=\"showTime\"\n    hourFormat=\"24\"\n    dateFormat=\"dd/mm/yy\"\n    [readonlyInput]=\"false\"\n    class=\"w-full\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n", styles: [":host::ng-deep .p-datepicker{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: DatePickerModule }, { kind: "component", type: i3.DatePicker, selector: "p-datePicker, p-datepicker, p-date-picker", inputs: ["iconDisplay", "styleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "showTransitionOptions", "hideTransitionOptions", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "ngmodule", type: SelectModule }, { kind: "ngmodule", type: AutoFocusModule }, { kind: "directive", type: i6.AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "ngmodule", type: AutoCompleteModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputDateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-input-date', imports: [
                        CommonModule,
                        DatePickerModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FloatLabelModule,
                        TooltipModule,
                        SelectModule,
                        AutoFocusModule,
                        AutoCompleteModule
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: InputDateComponent,
                            multi: true
                        }
                    ], template: "<p-floatLabel>\n  <p-datepicker\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n    [iconDisplay]=\"'input'\"\n    [showIcon]=\"true\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    appendTo=\"body\"\n      [pAutoFocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [touchUI]=\"false\"\n    [showTime]=\"showTime\"\n    hourFormat=\"24\"\n    dateFormat=\"dd/mm/yy\"\n    [readonlyInput]=\"false\"\n    class=\"w-full\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n", styles: [":host::ng-deep .p-datepicker{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: FieldsService }], propDecorators: { showTime: [{
                type: Input
            }] } });

class CrudService {
    http;
    constructor(http) {
        this.http = http;
    }
    save(route, body) { return this.http.post(route, body); }
    update(route, id, body) { return this.http.put(`${route}/${id}`, body); }
    delete(route, id) { return this.http.delete(`${route}/${id}`); }
    get(route, id) { return this.http.get(`${route}/${id}`); }
    list(route, request) {
        const params = new HttpParams()
            .set('size', String(request.size ?? 10)).set('offset', String(request.offset ?? 0))
            .set('filter', request.filter ?? '').set('order', request.order ?? '')
            .set('displayFields', request.displayFields ?? '*');
        return this.http.get(route, { params });
    }
    onSave(route, body) { return this.save(route, body); }
    onUpdate(route, id, body) { return this.update(route, id, body); }
    onDelete(route, id) { return this.delete(route, id); }
    onGet(route, id) { return this.get(route, id); }
    onGetAll(route, request) { return this.list(route, request); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CrudService, deps: [{ token: i1$1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CrudService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CrudService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }] });

class AutoCompleteComponent extends AppControlValueAccessor {
    fieldServiceInputText;
    crudService;
    autoComplete;
    optionLabel = "";
    route = "";
    defaultFilter = "";
    onSelectChange = new EventEmitter();
    itens = [];
    constructor(fieldServiceInputText, crudService) {
        super(fieldServiceInputText);
        this.fieldServiceInputText = fieldServiceInputText;
        this.crudService = crudService;
    }
    writeValue(value) {
        super.writeValue(value);
        if (value === null || value === undefined || value === '') {
            queueMicrotask(() => this.autoComplete?.clear());
        }
    }
    onFilter(value) {
        var req = this.onRequestData(value);
        this.crudService.onGetAll(this.route, req).subscribe({
            next: (res) => {
                this.itens = res.contents;
            },
            error: (err) => {
            }
        });
    }
    onRequestData(value) {
        let req = new RequestData();
        req.size = 5;
        req.offset = 0;
        var filter = "";
        if (value.query !== "") {
            filter = ` ${this.optionLabel} eq ${value.query}`;
        }
        if (filter !== "") {
            req.filter = (this.defaultFilter !== "" ? this.defaultFilter + " and " : "") + filter;
        }
        else {
            req.filter = this.defaultFilter;
        }
        return req;
    }
    onSelected() {
        this.onSelectChange.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AutoCompleteComponent, deps: [{ token: FieldsService }, { token: CrudService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AutoCompleteComponent, isStandalone: true, selector: "sv-auto-complete", inputs: { optionLabel: "optionLabel", route: "route", defaultFilter: "defaultFilter" }, outputs: { onSelectChange: "onSelectChange" }, providers: [
            CrudService,
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: AutoCompleteComponent,
                multi: true
            }
        ], viewQueries: [{ propertyName: "autoComplete", first: true, predicate: AutoComplete, descendants: true }], usesInheritance: true, ngImport: i0, template: "<p-floatLabel>\n  <p-autoComplete\n    (onSelect)=\"onSelected()\"\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n      [pAutoFocus]=\"focus\"\n    [dropdown]=\"true\"\n    [autofocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [suggestions]=\"itens\"\n    (completeMethod)=\"onFilter($event)\"\n    [optionLabel]=\"optionLabel\" class=\"w-full\"\n    appendTo=\"body\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n\n", styles: [":host::ng-deep .p-autocomplete{width:100%}:host::ng-deep .p-inputtext{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: AutoCompleteModule }, { kind: "component", type: i4$2.AutoComplete, selector: "p-autoComplete, p-autocomplete, p-auto-complete", inputs: ["minLength", "minQueryLength", "delay", "panelStyle", "styleClass", "panelStyleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "readonly", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "autoHighlight", "forceSelection", "type", "autoZIndex", "baseZIndex", "ariaLabel", "dropdownAriaLabel", "ariaLabelledBy", "dropdownIcon", "unique", "group", "completeOnFocus", "showClear", "dropdown", "showEmptyMessage", "dropdownMode", "multiple", "addOnTab", "tabindex", "dataKey", "emptyMessage", "showTransitionOptions", "hideTransitionOptions", "autofocus", "autocomplete", "optionGroupChildren", "optionGroupLabel", "overlayOptions", "suggestions", "optionLabel", "optionValue", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "selectOnFocus", "searchLocale", "optionDisabled", "focusOnHover", "typeahead", "addOnBlur", "separator", "appendTo", "motionOptions"], outputs: ["completeMethod", "onSelect", "onUnselect", "onAdd", "onFocus", "onBlur", "onDropdownClick", "onClear", "onInputKeydown", "onKeyUp", "onShow", "onHide", "onLazyLoad"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "ngmodule", type: AutoFocusModule }, { kind: "directive", type: i6.AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AutoCompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-auto-complete', imports: [
                        CommonModule,
                        AutoCompleteModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FloatLabelModule,
                        TooltipModule,
                        AutoFocusModule
                    ], providers: [
                        CrudService,
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: AutoCompleteComponent,
                            multi: true
                        }
                    ], template: "<p-floatLabel>\n  <p-autoComplete\n    (onSelect)=\"onSelected()\"\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n      [pAutoFocus]=\"focus\"\n    [dropdown]=\"true\"\n    [autofocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [suggestions]=\"itens\"\n    (completeMethod)=\"onFilter($event)\"\n    [optionLabel]=\"optionLabel\" class=\"w-full\"\n    appendTo=\"body\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n\n", styles: [":host::ng-deep .p-autocomplete{width:100%}:host::ng-deep .p-inputtext{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: FieldsService }, { type: CrudService }], propDecorators: { autoComplete: [{
                type: ViewChild,
                args: [AutoComplete]
            }], optionLabel: [{
                type: Input
            }], route: [{
                type: Input
            }], defaultFilter: [{
                type: Input
            }], onSelectChange: [{
                type: Output
            }] } });

class DropdownComponent extends AppControlValueAccessor {
    fieldServiceInputText;
    options = [];
    optionLabel = "";
    optionValue = "";
    constructor(fieldServiceInputText) {
        super(fieldServiceInputText);
        this.fieldServiceInputText = fieldServiceInputText;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DropdownComponent, deps: [{ token: FieldsService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DropdownComponent, isStandalone: true, selector: "sv-dropdown", inputs: { options: "options", optionLabel: "optionLabel", optionValue: "optionValue" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: DropdownComponent,
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "<p-floatLabel>\n  <p-select\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n      [pAutoFocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [options]=\"options\"\n    [optionLabel]=\"optionLabel\"\n    [optionValue]=\"optionValue\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    appendTo=\"body\"\n    class=\"w-full\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n", styles: [":host::ng-deep .p-select{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: SelectModule }, { kind: "component", type: i3$1.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "ngmodule", type: AutoCompleteModule }, { kind: "ngmodule", type: AutoFocusModule }, { kind: "directive", type: i6.AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-dropdown', imports: [
                        CommonModule,
                        SelectModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FloatLabelModule,
                        TooltipModule,
                        AutoCompleteModule,
                        AutoFocusModule
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: DropdownComponent,
                            multi: true
                        }
                    ], template: "<p-floatLabel>\n  <p-select\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n      [pAutoFocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [options]=\"options\"\n    [optionLabel]=\"optionLabel\"\n    [optionValue]=\"optionValue\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    appendTo=\"body\"\n    class=\"w-full\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n", styles: [":host::ng-deep .p-select{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: FieldsService }], propDecorators: { options: [{
                type: Input
            }], optionLabel: [{
                type: Input
            }], optionValue: [{
                type: Input
            }] } });

var Action;
(function (Action) {
    Action[Action["DELETE"] = 0] = "DELETE";
    Action[Action["EDIT"] = 1] = "EDIT";
    Action[Action["ADD"] = 2] = "ADD";
})(Action || (Action = {}));
class DatatableComponent {
    confirmationService;
    translateService;
    datePipe;
    router;
    platformId;
    libraryConfig;
    sidebarVisible = false;
    quickSearch = "";
    filterValues = {};
    appliedFilter = "";
    orderField = "";
    orderDirection = '';
    tableStyle = { width: "100%", "min-width": "42rem" };
    config = new DataTable();
    loading = false;
    createDisabled = false;
    createDisabledReason = '';
    mobileSentinel;
    onRegister = new EventEmitter();
    onRefresh = new EventEmitter();
    mobileObserver;
    requestingNextPage = false;
    constructor(confirmationService, translateService, datePipe, router, platformId, libraryConfig) {
        this.confirmationService = confirmationService;
        this.translateService = translateService;
        this.datePipe = datePipe;
        this.router = router;
        this.platformId = platformId;
        this.libraryConfig = libraryConfig;
    }
    ngOnChanges(changes) {
        if (changes["config"] && !changes["config"].firstChange) {
            this.quickSearch = "";
            this.filterValues = {};
            this.appliedFilter = "";
            this.orderField = "";
            this.orderDirection = "";
            this.sidebarVisible = false;
            this.initializeFilterDefaults();
            this.restoreFilterState();
        }
        if (changes["config"]?.firstChange) {
            this.initializeFilterDefaults();
            this.restoreFilterState();
        }
        if (changes["loading"] && !this.loading) {
            this.requestingNextPage = false;
            if (isPlatformBrowser(this.platformId)) {
                setTimeout(() => this.loadNextMobilePage());
            }
        }
    }
    ngAfterViewInit() {
        if (!isPlatformBrowser(this.platformId) || !this.mobileSentinel)
            return;
        this.mobileObserver = new IntersectionObserver(entries => {
            if (entries.some(entry => entry.isIntersecting))
                this.loadNextMobilePage();
        }, { rootMargin: '240px 0px' });
        this.mobileObserver.observe(this.mobileSentinel.nativeElement);
    }
    ngOnDestroy() {
        this.mobileObserver?.disconnect();
    }
    onRowData(row, header, col) {
        const keys = header.split(".");
        let value = keys.reduce((obj, key) => (obj && obj[key] !== undefined ? obj[key] : null), row);
        return this.onCustomValue(value, col);
    }
    onCustomValue(value, col) {
        if (col.customValue) {
            switch (col.customValue) {
                case "MONEY":
                    value = parseFloat(value).toFixed(2);
                    break;
                case "DATE":
                    value = this.datePipe.transform(value, 'dd/MM/yyyy');
                    break;
                default:
                    break;
            }
        }
        return value;
    }
    pageChange($event) {
        var data = new RequestData();
        data.size = $event.rows;
        data.offset = $event.page ? $event.page + 1 : 0;
        data.filter = this.appliedFilter;
        data.order = this.currentOrder();
        this.onRefresh.emit(data);
    }
    loadNextMobilePage() {
        if (!isPlatformBrowser(this.platformId)
            || !window.matchMedia('(max-width: 768px)').matches
            || this.loading || this.requestingNextPage
            || this.config.values.length >= this.config.totalRecords)
            return;
        const data = new RequestData();
        data.size = this.config.size;
        data.offset = this.config.page + 1;
        data.filter = this.appliedFilter;
        data.order = this.currentOrder();
        data.append = true;
        this.requestingNextPage = true;
        this.onRefresh.emit(data);
    }
    onShowFilters() {
        this.sidebarVisible = !this.sidebarVisible;
    }
    onRegisterData(item, action) {
        if (action === Action.ADD && this.createDisabled)
            return;
        let obj = {
            data: item,
            action: action
        };
        this.onRegister.emit(obj);
    }
    onRefreshData() {
        this.quickSearch = "";
        this.filterValues = {};
        this.initializeFilterDefaults();
        this.appliedFilter = "";
        this.orderField = "";
        this.orderDirection = "";
        this.sidebarVisible = false;
        this.clearStoredFilterState();
        this.onRefresh.emit(new RequestData());
    }
    onApplyFilters() {
        this.appliedFilter = this.buildFilter();
        this.persistFilterState();
        this.sidebarVisible = false;
        const request = new RequestData();
        request.filter = this.appliedFilter;
        request.order = this.currentOrder();
        this.onRefresh.emit(request);
    }
    onQuickSearch() {
        const value = this.sanitizeFilterValue(this.quickSearch);
        this.filterValues = {};
        const field = this.config.filters[0]?.field;
        this.appliedFilter = value && field ? field + " eq " + value : "";
        this.persistFilterState();
        const request = new RequestData();
        request.filter = this.appliedFilter;
        request.order = this.currentOrder();
        this.onRefresh.emit(request);
    }
    onSort(field) {
        if (this.orderField !== field) {
            this.orderField = field;
            this.orderDirection = 'asc';
        }
        else if (this.orderDirection === 'asc') {
            this.orderDirection = 'desc';
        }
        else {
            this.orderField = '';
            this.orderDirection = '';
        }
        this.persistFilterState();
        const request = new RequestData();
        request.filter = this.appliedFilter;
        request.order = this.currentOrder();
        this.onRefresh.emit(request);
    }
    sortIcon(field) {
        if (this.orderField !== field || !this.orderDirection)
            return 'pi pi-sort-alt';
        return this.orderDirection === 'asc' ? 'pi pi-sort-amount-up-alt' : 'pi pi-sort-amount-down';
    }
    isSorted(field) {
        return this.orderField === field && !!this.orderDirection;
    }
    buildFilter() {
        return this.config.filters
            .map(filter => {
            if (filter.type === 'field-select')
                return '';
            const value = this.filterValue(filter);
            if (!value)
                return "";
            const field = filter.fieldSourceKey
                ? this.filterValues[filter.fieldSourceKey] || filter.field
                : filter.field;
            return filter.operator === "nullability"
                ? field + " " + value
                : field + " " + (filter.operator ?? "eq") + " " + value;
        })
            .filter(Boolean)
            .join(" and ");
    }
    sanitizeFilterValue(value) {
        return value.trim().replace(/\s+(and|or)\s+/gi, " ");
    }
    filterValue(filter) {
        const value = this.filterValues[filter.key ?? filter.field];
        if (value === null || value === undefined || value === '')
            return '';
        if (filter.type === 'entity-select')
            return value.id ?? value.hash ?? '';
        if (filter.type === 'date')
            return this.localDate(value);
        return this.sanitizeFilterValue(String(value));
    }
    localDate(value) {
        if (typeof value === 'string')
            return value;
        const year = value.getFullYear();
        const month = String(value.getMonth() + 1).padStart(2, '0');
        const day = String(value.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    initializeFilterDefaults() {
        this.config.filters.forEach(filter => {
            if (filter.defaultValue !== undefined) {
                this.filterValues[filter.key ?? filter.field] = filter.defaultValue;
            }
        });
    }
    restoreFilterState() {
        if (!isPlatformBrowser(this.platformId) || !this.config.storageKey)
            return;
        const rawState = sessionStorage.getItem(this.filterStorageKey());
        if (!rawState)
            return;
        try {
            const state = JSON.parse(rawState);
            this.filterValues = state.filterValues ?? this.filterValues;
            this.config.filters.filter(filter => filter.type === 'date').forEach(filter => {
                const key = filter.key ?? filter.field;
                const value = this.filterValues[key];
                if (typeof value === 'string' && value)
                    this.filterValues[key] = new Date(`${value}T00:00:00`);
            });
            this.appliedFilter = state.appliedFilter ?? '';
            this.quickSearch = state.quickSearch ?? '';
            this.orderField = state.orderField ?? '';
            this.orderDirection = state.orderDirection ?? '';
            if (this.appliedFilter || this.currentOrder()) {
                const request = new RequestData();
                request.filter = this.appliedFilter;
                request.order = this.currentOrder();
                queueMicrotask(() => this.onRefresh.emit(request));
            }
        }
        catch {
            sessionStorage.removeItem(this.filterStorageKey());
        }
    }
    persistFilterState() {
        if (!isPlatformBrowser(this.platformId) || !this.config.storageKey)
            return;
        const serializedValues = { ...this.filterValues };
        this.config.filters.filter(filter => filter.type === 'date').forEach(filter => {
            const key = filter.key ?? filter.field;
            const value = serializedValues[key];
            if (value)
                serializedValues[key] = this.localDate(value);
        });
        sessionStorage.setItem(this.filterStorageKey(), JSON.stringify({
            filterValues: serializedValues,
            appliedFilter: this.appliedFilter,
            quickSearch: this.quickSearch,
            orderField: this.orderField,
            orderDirection: this.orderDirection
        }));
    }
    clearStoredFilterState() {
        if (isPlatformBrowser(this.platformId) && this.config.storageKey) {
            sessionStorage.removeItem(this.filterStorageKey());
        }
    }
    filterStorageKey() {
        return `${this.libraryConfig.filterStoragePrefix}:${this.config.storageKey}`;
    }
    currentOrder() {
        return this.orderField && this.orderDirection ? `${this.orderField} ${this.orderDirection}` : '';
    }
    translatedOptions(options) {
        return (options ?? []).map(option => ({ ...option, label: this.translateService.translate(option.label) }));
    }
    get reportScreen() {
        return this.router.url.split('?')[0];
    }
    get reportData() {
        return {
            contents: this.config.values,
            total: this.config.totalRecords,
            size: this.config.size,
            offset: Math.max(0, this.config.page - 1),
            filter: this.appliedFilter,
            order: this.currentOrder(),
        };
    }
    onDeleteData(item, action) {
        this.confirmationService.confirm({
            message: this.translateService.translate("common_message_confirmation_delete"),
            header: this.translateService.translate("common_message_header_confirmation_delete"),
            icon: 'pi pi-info-circle',
            acceptButtonStyleClass: "p-button-danger p-button-text",
            rejectButtonStyleClass: "p-button-text p-button-text",
            acceptLabel: this.translateService.translate("common_action_yes"),
            rejectLabel: this.translateService.translate("common_action_no"),
            acceptIcon: "none",
            rejectIcon: "none",
            accept: () => {
                this.onRegisterData(item, action);
            },
            reject: () => {
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DatatableComponent, deps: [{ token: i1$2.ConfirmationService }, { token: TranslateService }, { token: i1.DatePipe }, { token: i4$3.Router }, { token: PLATFORM_ID }, { token: SMARTVERSE_COMPONENTS_CONFIG }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: DatatableComponent, isStandalone: true, selector: "sv-datatable", inputs: { config: "config", loading: "loading", createDisabled: "createDisabled", createDisabledReason: "createDisabledReason" }, outputs: { onRegister: "onRegister", onRefresh: "onRefresh" }, providers: [
            ConfirmationService,
            DatePipe
        ], viewQueries: [{ propertyName: "mobileSentinel", first: true, predicate: ["mobileSentinel"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"datatable\">\n  <p-confirmDialog/>\n\n  <div class=\"datatable__toolbar\">\n    <p-iconField iconPosition=\"left\" class=\"datatable__search\">\n      <p-inputIcon><i class=\"pi pi-search\"></i></p-inputIcon>\n      <input pInputText type=\"search\" [(ngModel)]=\"quickSearch\" (keyup.enter)=\"onQuickSearch()\"\n             [placeholder]=\"translateService.translate('datatable_search')\"/>\n    </p-iconField>\n\n    <div class=\"datatable__toolbar-actions\">\n      <ng-content select=\"[datatableToolbarAction]\"/>\n      @if (config.showReports) {\n        <sv-screen-report-button [screen]=\"reportScreen\" [data]=\"reportData\"/>\n      }\n      <p-button\n        type=\"button\"\n        icon=\"pi pi-refresh\"\n        [text]=\"true\"\n        [rounded]=\"true\"\n        [ariaLabel]=\"translateService.translate('datatable_refresh')\"\n        (onClick)=\"onRefreshData()\"/>\n      <p-button\n        type=\"button\"\n        icon=\"pi pi-filter\"\n        [outlined]=\"true\"\n        [label]=\"translateService.translate('datatable_filters')\"\n        (onClick)=\"onShowFilters()\"/>\n      <p-button\n        type=\"button\"\n        icon=\"pi pi-plus\"\n        [disabled]=\"createDisabled\"\n        [pTooltip]=\"createDisabled ? createDisabledReason : ''\"\n        [label]=\"translateService.translate('datatable_add')\"\n        (onClick)=\"onRegisterData(null, 2)\"/>\n    </div>\n  </div>\n\n  <div class=\"datatable__content\">\n    <p-table\n      [columns]=\"config.fields\"\n      [value]=\"config.values\"\n      [rows]=\"config.size\"\n      styleClass=\"datatable__prime p-datatable-sm\"\n      dataKey=\"id\"\n      [tableStyle]=\"tableStyle\">\n      <ng-template pTemplate=\"header\" let-columns>\n        <tr>\n          <th class=\"datatable__select\">\n            <p-tableHeaderCheckbox/>\n          </th>\n          @for (col of columns; track col.field) {\n            <th [style.width]=\"col.width || null\">\n              <button type=\"button\" class=\"datatable__sort\" [class.is-active]=\"isSorted(col.field)\"\n                      (click)=\"onSort(col.field)\">\n                <span>{{ translateService.translate(col.header) }}</span>\n                <i [class]=\"sortIcon(col.field)\"></i>\n              </button>\n            </th>\n          }\n          <th class=\"datatable__actions-column\">{{ translateService.translate('datatable_actions') }}</th>\n        </tr>\n      </ng-template>\n\n      <ng-template pTemplate=\"body\" let-rowData let-columns=\"columns\">\n        <tr>\n          <td class=\"datatable__select\">\n            <p-tableCheckbox [value]=\"rowData\"/>\n          </td>\n          @for (col of columns; track col.field) {\n            <td [style.width]=\"col.width || null\" [title]=\"onRowData(rowData, col.field, col)\">\n              <span class=\"datatable__cell-value\">{{ onRowData(rowData, col.field, col) }}</span>\n            </td>\n          }\n          <td class=\"datatable__actions-column\">\n            <div class=\"datatable__row-actions\">\n              <p-button\n                type=\"button\"\n                icon=\"pi pi-pencil\"\n                [text]=\"true\"\n                [rounded]=\"true\"\n                [ariaLabel]=\"translateService.translate('datatable_edit')\"\n                (onClick)=\"onRegisterData(rowData, 1)\"/>\n              <p-button\n                type=\"button\"\n                icon=\"pi pi-trash\"\n                severity=\"danger\"\n                [text]=\"true\"\n                [rounded]=\"true\"\n                [ariaLabel]=\"translateService.translate('datatable_delete')\"\n                (onClick)=\"onDeleteData(rowData, 0)\"/>\n            </div>\n          </td>\n        </tr>\n      </ng-template>\n\n      <ng-template pTemplate=\"emptymessage\">\n        <tr>\n          <td [attr.colspan]=\"config.fields.length + 2\" class=\"datatable__empty-cell\">\n            <div class=\"datatable__empty\">\n              <svg viewBox=\"0 0 220 150\" role=\"img\" aria-hidden=\"true\">\n                <rect x=\"38\" y=\"24\" width=\"144\" height=\"98\" rx=\"12\" class=\"empty-surface\"/>\n                <path d=\"M58 49h68M58 69h104M58 89h52\" class=\"empty-line\"/>\n                <circle cx=\"151\" cy=\"103\" r=\"27\" class=\"empty-accent\"/>\n                <path d=\"m171 123 18 18M141 103h20\" class=\"empty-icon\"/>\n              </svg>\n              <strong>{{ translateService.translate('datatable_empty_title') }}</strong>\n              <span>{{ translateService.translate('datatable_empty_description') }}</span>\n              <p-button\n                type=\"button\"\n                icon=\"pi pi-plus\"\n                [disabled]=\"createDisabled\"\n                [pTooltip]=\"createDisabled ? createDisabledReason : ''\"\n                [outlined]=\"true\"\n                [label]=\"translateService.translate('datatable_add_first')\"\n                (onClick)=\"onRegisterData(null, 2)\"/>\n            </div>\n          </td>\n        </tr>\n      </ng-template>\n    </p-table>\n    <div class=\"datatable__mobile-list\">\n      @for (rowData of config.values; track rowData.id ?? $index) {\n        <article class=\"datatable__mobile-card\">\n          <div class=\"datatable__mobile-fields\">\n            @for (col of config.fields; track col.field) {\n              <div class=\"datatable__mobile-field\">\n                <span>{{ translateService.translate(col.header) }}</span><strong>{{ onRowData(rowData, col.field, col) }}</strong>\n              </div>\n            }\n          </div>\n          <div class=\"datatable__mobile-actions\">\n            <p-button type=\"button\" icon=\"pi pi-pencil\" [text]=\"true\" [rounded]=\"true\"\n                      [ariaLabel]=\"translateService.translate('datatable_edit')\"\n                      (onClick)=\"onRegisterData(rowData, 1)\"/>\n            <p-button type=\"button\" icon=\"pi pi-trash\" severity=\"danger\" [text]=\"true\" [rounded]=\"true\"\n                      [ariaLabel]=\"translateService.translate('datatable_delete')\"\n                      (onClick)=\"onDeleteData(rowData, 0)\"/>\n          </div>\n        </article>\n      } @empty {\n        <div class=\"datatable__empty datatable__mobile-empty\">\n          <svg viewBox=\"0 0 220 150\" role=\"img\" aria-hidden=\"true\">\n            <rect x=\"38\" y=\"24\" width=\"144\" height=\"98\" rx=\"12\" class=\"empty-surface\"/>\n            <path d=\"M58 49h68M58 69h104M58 89h52\" class=\"empty-line\"/>\n            <circle cx=\"151\" cy=\"103\" r=\"27\" class=\"empty-accent\"/>\n            <path d=\"m171 123 18 18M141 103h20\" class=\"empty-icon\"/>\n          </svg>\n          <strong>{{ translateService.translate('datatable_empty_title') }}</strong><span>{{ translateService.translate('datatable_empty_description') }}</span>\n          <p-button type=\"button\" icon=\"pi pi-plus\" [disabled]=\"createDisabled\"\n                    [pTooltip]=\"createDisabled ? createDisabledReason : ''\" [outlined]=\"true\"\n                    [label]=\"translateService.translate('datatable_add_first')\" (onClick)=\"onRegisterData(null, 2)\"/>\n        </div>\n      }\n      <div #mobileSentinel class=\"datatable__mobile-sentinel\" aria-hidden=\"true\">@if (loading && config.values.length) {\n        <i class=\"pi pi-spin pi-spinner\"></i>\n      }</div>\n    </div>\n  </div>\n\n  <footer class=\"datatable__footer\">\n    <span class=\"datatable__count\">\n      {{ config.totalRecords }} {{ translateService.translate('datatable_records') }}\n    </span>\n    <p-paginator\n      (onPageChange)=\"pageChange($event)\"\n      [first]=\"(config.page - 1) * config.size\"\n      [rows]=\"config.size\"\n      [totalRecords]=\"config.totalRecords\"\n      [rowsPerPageOptions]=\"[10, 20, 30, 50]\"\n      appendTo=\"body\"\n      dropdownAppendTo=\"body\"/>\n  </footer>\n</div>\n\n<p-drawer [(visible)]=\"sidebarVisible\" position=\"right\" [modal]=\"false\" [blockScroll]=\"false\" [dismissible]=\"true\"\n          appendTo=\"body\" styleClass=\"datatable__filter-drawer\">\n  <ng-template pTemplate=\"header\">\n    <div class=\"datatable__drawer-title\">\n      <i class=\"pi pi-filter\"></i>\n      <span>{{ translateService.translate('datatable_filters') }}</span>\n    </div>\n  </ng-template>\n  <ng-template pTemplate=\"content\">\n    <div class=\"datatable__filter-form\">\n      <p class=\"datatable__filter-description\">{{ translateService.translate('datatable_filters_description') }}</p>\n      @for (filter of config.filters; track filter.key || filter.field) {\n        @if (filter.type === 'field-select') {\n          <sv-dropdown class=\"datatable__filter-field\" [(ngModel)]=\"filterValues[filter.key || filter.field]\"\n                        [name]=\"filter.key || filter.field\"\n                        [label]=\"translateService.translate(filter.label || filter.field)\"\n                        [options]=\"translatedOptions(filter.options)\" optionLabel=\"label\" optionValue=\"value\"/>\n        } @else if (filter.type === 'entity-select') {\n          <sv-auto-complete class=\"datatable__filter-field\" [(ngModel)]=\"filterValues[filter.key || filter.field]\"\n                             [name]=\"filter.key || filter.field\"\n                             [label]=\"translateService.translate(filter.label || filter.field)\"\n                             [route]=\"filter.route || ''\" [optionLabel]=\"filter.optionLabel || 'description'\"\n                             type=\"text\"/>\n        } @else if (filter.type === 'date') {\n          <sv-input-date class=\"datatable__filter-field\" [(ngModel)]=\"filterValues[filter.key || filter.field]\"\n                          [name]=\"filter.key || filter.field\"\n                          [label]=\"translateService.translate(filter.label || filter.field)\"/>\n        } @else {\n          <label class=\"datatable__filter-field\">\n            <span>{{ translateService.translate(filter.label || filter.field) }}</span>\n          @if (filter.type === 'select') {\n            <p-select [(ngModel)]=\"filterValues[filter.key || filter.field]\" [options]=\"translatedOptions(filter.options)\"\n                      optionLabel=\"label\" optionValue=\"value\" [showClear]=\"true\"\n                      [placeholder]=\"translateService.translate('datatable_all')\" appendTo=\"body\"/>\n          } @else {\n            <input pInputText [(ngModel)]=\"filterValues[filter.key || filter.field]\" type=\"text\"\n                   [placeholder]=\"translateService.translate('datatable_filter_by') + ' ' + translateService.translate(filter.label || filter.field).toLowerCase()\"/>\n          }\n          </label>\n        }\n      }\n      @if (!config.filters.length) {\n        <div class=\"datatable__filter-empty\"><i\n          class=\"pi pi-sliders-h\"></i><span>{{ translateService.translate('datatable_filters_description') }}</span>\n        </div>\n      }\n    </div>\n  </ng-template>\n  <ng-template pTemplate=\"footer\">\n    <div class=\"datatable__filter-actions\">\n      <p-button icon=\"pi pi-times\" [outlined]=\"true\" [label]=\"translateService.translate('datatable_clear')\"\n                (onClick)=\"onRefreshData()\"/>\n      <p-button icon=\"pi pi-check\" [label]=\"translateService.translate('datatable_apply_filters')\"\n                (onClick)=\"onApplyFilters()\"/>\n    </div>\n  </ng-template>\n</p-drawer>\n", styles: [":host{display:block;min-height:0;height:100%}.datatable{display:flex;flex-direction:column;min-height:32rem;height:100%;overflow:hidden;border:1px solid var(--p-content-border-color);border-radius:12px;background:var(--p-content-background)}.datatable__toolbar{display:flex;align-items:center;justify-content:space-between;flex:0 0 auto;gap:1rem;padding:.75rem 1rem;border-bottom:1px solid var(--p-content-border-color)}.datatable__search{width:min(22rem,42%)}.datatable__search input{width:100%;height:2.25rem;font-size:.8rem}.datatable__toolbar-actions,.datatable__row-actions{display:flex;align-items:center;gap:.5rem}.datatable__content{flex:1 1 auto;min-height:0;overflow:auto}.datatable__mobile-list{display:none}:host ::ng-deep .datatable__prime .p-datatable-table{table-layout:auto}:host ::ng-deep .datatable__prime .p-datatable-thead>tr>th{position:sticky;z-index:2;top:0;padding:.55rem .65rem;border-color:var(--p-content-border-color);background:var(--p-content-background);color:var(--p-text-muted-color);font-size:.68rem;font-weight:700;letter-spacing:.045em;text-transform:uppercase;white-space:nowrap}.datatable__sort{align-items:center;background:transparent;border:0;color:inherit;cursor:pointer;display:inline-flex;font:inherit;font-weight:inherit;gap:.4rem;letter-spacing:inherit;padding:0;text-transform:inherit}.datatable__sort i{font-size:.65rem;opacity:.45}.datatable__sort:hover,.datatable__sort.is-active{color:var(--p-primary-color)}.datatable__sort.is-active i{opacity:1}:host ::ng-deep .datatable__prime .p-datatable-tbody>tr>td{max-width:22rem;padding:.48rem .65rem;border-color:var(--p-content-border-color);color:var(--p-text-color);font-size:.76rem;line-height:1.25;vertical-align:middle}:host ::ng-deep .datatable__prime .p-datatable-tbody>tr:hover>td{background:color-mix(in srgb,var(--p-primary-color),transparent 96%)}.datatable__cell-value{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.datatable__select{width:2.5rem;min-width:2.5rem;text-align:center}.datatable__actions-column{width:5.5rem;min-width:5.5rem;text-align:center}.datatable__row-actions{justify-content:center;gap:.15rem}:host ::ng-deep .datatable__row-actions .p-button{width:1.9rem;height:1.9rem;padding:0}.datatable__empty-cell{height:clamp(19rem,48vh,32rem);border:0}.datatable__empty{display:flex;align-items:center;justify-content:center;flex-direction:column;height:100%;padding:2rem;text-align:center}.datatable__empty svg{width:min(13rem,48vw);margin-bottom:.75rem}.empty-surface{fill:var(--p-form-field-background);stroke:var(--p-content-border-color);stroke-width:2}.empty-line{fill:none;stroke:var(--p-text-muted-color);stroke-linecap:round;stroke-width:5;opacity:.45}.empty-accent{fill:color-mix(in srgb,var(--p-primary-color),transparent 82%);stroke:var(--p-primary-color);stroke-width:3}.empty-icon{fill:none;stroke:var(--p-primary-color);stroke-linecap:round;stroke-width:5}.datatable__empty strong{margin-bottom:.35rem;font-size:1rem;font-weight:650}.datatable__empty span{max-width:26rem;margin-bottom:1.25rem;color:var(--p-text-muted-color);font-size:.8rem}.datatable__footer{display:flex;align-items:center;justify-content:space-between;flex:0 0 auto;min-height:3.25rem;padding:.25rem .75rem .25rem 1rem;border-top:1px solid var(--p-content-border-color);background:var(--p-content-background)}.datatable__count{color:var(--p-text-muted-color);font-size:.72rem;white-space:nowrap}:host ::ng-deep .datatable__footer .p-paginator{padding:0;background:transparent;font-size:.75rem}:host ::ng-deep .datatable__footer .p-paginator-page,:host ::ng-deep .datatable__footer .p-paginator-next,:host ::ng-deep .datatable__footer .p-paginator-prev,:host ::ng-deep .datatable__footer .p-paginator-first,:host ::ng-deep .datatable__footer .p-paginator-last{min-width:2rem;height:2rem}.datatable__drawer-title{display:flex;align-items:center;gap:.75rem;font-size:1.1rem;font-weight:600}.datatable__filter-form{display:flex;flex-direction:column;gap:1.25rem}.datatable__filter-description{margin:0;color:var(--p-text-muted-color);font-size:.8rem;line-height:1.5}.datatable__filter-field{display:flex;flex-direction:column;gap:.5rem}.datatable__filter-field>span{font-size:.78rem;font-weight:600}.datatable__filter-field>input{width:100%}:host ::ng-deep .datatable__filter-field .p-select{width:100%}:host ::ng-deep sv-auto-complete.datatable__filter-field .p-autocomplete,:host ::ng-deep sv-input-date.datatable__filter-field .p-datepicker,:host ::ng-deep sv-dropdown.datatable__filter-field .p-select{width:100%}.datatable__filter-actions{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}:host ::ng-deep .datatable__filter-actions .p-button{width:100%}.datatable__filter-empty{display:flex;align-items:center;flex-direction:column;gap:1rem;padding:3rem 1rem;color:var(--p-text-muted-color);text-align:center}.datatable__filter-empty i{font-size:2rem;color:var(--p-primary-color)}@media(max-width:768px){.datatable{min-height:28rem;border-right:0;border-left:0;border-radius:0}.datatable__toolbar{align-items:stretch;flex-direction:column}.datatable__search{width:100%}.datatable__toolbar-actions{justify-content:flex-end}.datatable__toolbar-actions p-button:last-child{flex:1}:host ::ng-deep .datatable__toolbar-actions p-button:last-child .p-button{width:100%}:host ::ng-deep .datatable__prime{display:none}.datatable__mobile-list{display:flex;flex-direction:column;gap:.65rem;padding:.75rem}.datatable__mobile-card{display:flex;align-items:center;gap:.75rem;padding:.85rem .6rem .85rem .9rem;border:1px solid var(--p-content-border-color);border-radius:10px;background:var(--p-content-background)}.datatable__mobile-fields{display:grid;flex:1;min-width:0;gap:.55rem}.datatable__mobile-field{display:flex;min-width:0;flex-direction:column;gap:.15rem}.datatable__mobile-field span{color:var(--p-text-muted-color);font-size:.65rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase}.datatable__mobile-field strong{overflow:hidden;color:var(--p-text-color);font-size:.85rem;font-weight:550;text-overflow:ellipsis;white-space:nowrap}.datatable__mobile-actions{display:flex;flex:0 0 auto}.datatable__mobile-empty{min-height:22rem}.datatable__mobile-sentinel{display:flex;align-items:center;justify-content:center;min-height:2.5rem;color:var(--p-primary-color)}.datatable__footer{align-items:flex-start;flex-direction:column;gap:.25rem;padding:.5rem .75rem}:host ::ng-deep .datatable__footer .p-paginator{display:none}}\n"], dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i4.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "directive", type: i1$2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "ngmodule", type: TableModule }, { kind: "component", type: i6$1.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "selectionPageOnly", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowSelectable", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "exportFunction", "exportHeader", "stateKey", "stateStorage", "editMode", "groupRowsBy", "size", "showGridlines", "stripedRows", "groupRowsByOrder", "responsiveLayout", "breakpoint", "paginatorLocale", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "selectAll"], outputs: ["contextMenuSelectionChange", "selectAllChange", "selectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { kind: "component", type: i6$1.TableCheckbox, selector: "p-tableCheckbox", inputs: ["value", "disabled", "required", "index", "inputId", "name", "ariaLabel"] }, { kind: "component", type: i6$1.TableHeaderCheckbox, selector: "p-tableHeaderCheckbox", inputs: ["disabled", "inputId", "name", "ariaLabel"] }, { kind: "ngmodule", type: DrawerModule }, { kind: "component", type: i7.Drawer, selector: "p-drawer", inputs: ["appendTo", "motionOptions", "blockScroll", "style", "styleClass", "ariaCloseLabel", "autoZIndex", "baseZIndex", "modal", "closeButtonProps", "dismissible", "showCloseIcon", "closeOnEscape", "transitionOptions", "visible", "position", "fullScreen", "header", "maskStyle", "closable"], outputs: ["onShow", "onHide", "visibleChange"] }, { kind: "ngmodule", type: IconFieldModule }, { kind: "component", type: i8.IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "ngmodule", type: InputIconModule }, { kind: "component", type: i9.InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i10.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: PaginatorModule }, { kind: "component", type: i11.Paginator, selector: "p-paginator", inputs: ["pageLinkSize", "styleClass", "alwaysShow", "dropdownAppendTo", "templateLeft", "templateRight", "dropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showFirstLastIcon", "totalRecords", "rows", "rowsPerPageOptions", "showJumpToPageDropdown", "showJumpToPageInput", "jumpToPageItemTemplate", "showPageLinks", "locale", "dropdownItemTemplate", "first", "appendTo"], outputs: ["onPageChange"] }, { kind: "ngmodule", type: ConfirmDialogModule }, { kind: "component", type: i12.ConfirmDialog, selector: "p-confirmDialog, p-confirmdialog, p-confirm-dialog", inputs: ["header", "icon", "message", "style", "styleClass", "maskStyleClass", "acceptIcon", "acceptLabel", "closeAriaLabel", "acceptAriaLabel", "acceptVisible", "rejectIcon", "rejectLabel", "rejectAriaLabel", "rejectVisible", "acceptButtonStyleClass", "rejectButtonStyleClass", "closeOnEscape", "dismissableMask", "blockScroll", "rtl", "closable", "appendTo", "key", "autoZIndex", "baseZIndex", "transitionOptions", "focusTrap", "defaultFocus", "breakpoints", "modal", "visible", "position", "draggable"], outputs: ["onHide"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SelectModule }, { kind: "component", type: i3$1.Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i6$2.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "component", type: ScreenReportButtonComponent, selector: "sv-screen-report-button", inputs: ["screen", "data", "disabled", "outlined"] }, { kind: "component", type: InputDateComponent, selector: "sv-input-date", inputs: ["showTime"] }, { kind: "component", type: AutoCompleteComponent, selector: "sv-auto-complete", inputs: ["optionLabel", "route", "defaultFilter"], outputs: ["onSelectChange"] }, { kind: "component", type: DropdownComponent, selector: "sv-dropdown", inputs: ["options", "optionLabel", "optionValue"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DatatableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-datatable', imports: [
                        ButtonModule,
                        TableModule,
                        DrawerModule,
                        IconFieldModule,
                        InputIconModule,
                        InputTextModule,
                        PaginatorModule,
                        ConfirmDialogModule,
                        FormsModule,
                        SelectModule,
                        TooltipModule,
                        ScreenReportButtonComponent,
                        InputDateComponent,
                        AutoCompleteComponent,
                        DropdownComponent
                    ], providers: [
                        ConfirmationService,
                        DatePipe
                    ], template: "<div class=\"datatable\">\n  <p-confirmDialog/>\n\n  <div class=\"datatable__toolbar\">\n    <p-iconField iconPosition=\"left\" class=\"datatable__search\">\n      <p-inputIcon><i class=\"pi pi-search\"></i></p-inputIcon>\n      <input pInputText type=\"search\" [(ngModel)]=\"quickSearch\" (keyup.enter)=\"onQuickSearch()\"\n             [placeholder]=\"translateService.translate('datatable_search')\"/>\n    </p-iconField>\n\n    <div class=\"datatable__toolbar-actions\">\n      <ng-content select=\"[datatableToolbarAction]\"/>\n      @if (config.showReports) {\n        <sv-screen-report-button [screen]=\"reportScreen\" [data]=\"reportData\"/>\n      }\n      <p-button\n        type=\"button\"\n        icon=\"pi pi-refresh\"\n        [text]=\"true\"\n        [rounded]=\"true\"\n        [ariaLabel]=\"translateService.translate('datatable_refresh')\"\n        (onClick)=\"onRefreshData()\"/>\n      <p-button\n        type=\"button\"\n        icon=\"pi pi-filter\"\n        [outlined]=\"true\"\n        [label]=\"translateService.translate('datatable_filters')\"\n        (onClick)=\"onShowFilters()\"/>\n      <p-button\n        type=\"button\"\n        icon=\"pi pi-plus\"\n        [disabled]=\"createDisabled\"\n        [pTooltip]=\"createDisabled ? createDisabledReason : ''\"\n        [label]=\"translateService.translate('datatable_add')\"\n        (onClick)=\"onRegisterData(null, 2)\"/>\n    </div>\n  </div>\n\n  <div class=\"datatable__content\">\n    <p-table\n      [columns]=\"config.fields\"\n      [value]=\"config.values\"\n      [rows]=\"config.size\"\n      styleClass=\"datatable__prime p-datatable-sm\"\n      dataKey=\"id\"\n      [tableStyle]=\"tableStyle\">\n      <ng-template pTemplate=\"header\" let-columns>\n        <tr>\n          <th class=\"datatable__select\">\n            <p-tableHeaderCheckbox/>\n          </th>\n          @for (col of columns; track col.field) {\n            <th [style.width]=\"col.width || null\">\n              <button type=\"button\" class=\"datatable__sort\" [class.is-active]=\"isSorted(col.field)\"\n                      (click)=\"onSort(col.field)\">\n                <span>{{ translateService.translate(col.header) }}</span>\n                <i [class]=\"sortIcon(col.field)\"></i>\n              </button>\n            </th>\n          }\n          <th class=\"datatable__actions-column\">{{ translateService.translate('datatable_actions') }}</th>\n        </tr>\n      </ng-template>\n\n      <ng-template pTemplate=\"body\" let-rowData let-columns=\"columns\">\n        <tr>\n          <td class=\"datatable__select\">\n            <p-tableCheckbox [value]=\"rowData\"/>\n          </td>\n          @for (col of columns; track col.field) {\n            <td [style.width]=\"col.width || null\" [title]=\"onRowData(rowData, col.field, col)\">\n              <span class=\"datatable__cell-value\">{{ onRowData(rowData, col.field, col) }}</span>\n            </td>\n          }\n          <td class=\"datatable__actions-column\">\n            <div class=\"datatable__row-actions\">\n              <p-button\n                type=\"button\"\n                icon=\"pi pi-pencil\"\n                [text]=\"true\"\n                [rounded]=\"true\"\n                [ariaLabel]=\"translateService.translate('datatable_edit')\"\n                (onClick)=\"onRegisterData(rowData, 1)\"/>\n              <p-button\n                type=\"button\"\n                icon=\"pi pi-trash\"\n                severity=\"danger\"\n                [text]=\"true\"\n                [rounded]=\"true\"\n                [ariaLabel]=\"translateService.translate('datatable_delete')\"\n                (onClick)=\"onDeleteData(rowData, 0)\"/>\n            </div>\n          </td>\n        </tr>\n      </ng-template>\n\n      <ng-template pTemplate=\"emptymessage\">\n        <tr>\n          <td [attr.colspan]=\"config.fields.length + 2\" class=\"datatable__empty-cell\">\n            <div class=\"datatable__empty\">\n              <svg viewBox=\"0 0 220 150\" role=\"img\" aria-hidden=\"true\">\n                <rect x=\"38\" y=\"24\" width=\"144\" height=\"98\" rx=\"12\" class=\"empty-surface\"/>\n                <path d=\"M58 49h68M58 69h104M58 89h52\" class=\"empty-line\"/>\n                <circle cx=\"151\" cy=\"103\" r=\"27\" class=\"empty-accent\"/>\n                <path d=\"m171 123 18 18M141 103h20\" class=\"empty-icon\"/>\n              </svg>\n              <strong>{{ translateService.translate('datatable_empty_title') }}</strong>\n              <span>{{ translateService.translate('datatable_empty_description') }}</span>\n              <p-button\n                type=\"button\"\n                icon=\"pi pi-plus\"\n                [disabled]=\"createDisabled\"\n                [pTooltip]=\"createDisabled ? createDisabledReason : ''\"\n                [outlined]=\"true\"\n                [label]=\"translateService.translate('datatable_add_first')\"\n                (onClick)=\"onRegisterData(null, 2)\"/>\n            </div>\n          </td>\n        </tr>\n      </ng-template>\n    </p-table>\n    <div class=\"datatable__mobile-list\">\n      @for (rowData of config.values; track rowData.id ?? $index) {\n        <article class=\"datatable__mobile-card\">\n          <div class=\"datatable__mobile-fields\">\n            @for (col of config.fields; track col.field) {\n              <div class=\"datatable__mobile-field\">\n                <span>{{ translateService.translate(col.header) }}</span><strong>{{ onRowData(rowData, col.field, col) }}</strong>\n              </div>\n            }\n          </div>\n          <div class=\"datatable__mobile-actions\">\n            <p-button type=\"button\" icon=\"pi pi-pencil\" [text]=\"true\" [rounded]=\"true\"\n                      [ariaLabel]=\"translateService.translate('datatable_edit')\"\n                      (onClick)=\"onRegisterData(rowData, 1)\"/>\n            <p-button type=\"button\" icon=\"pi pi-trash\" severity=\"danger\" [text]=\"true\" [rounded]=\"true\"\n                      [ariaLabel]=\"translateService.translate('datatable_delete')\"\n                      (onClick)=\"onDeleteData(rowData, 0)\"/>\n          </div>\n        </article>\n      } @empty {\n        <div class=\"datatable__empty datatable__mobile-empty\">\n          <svg viewBox=\"0 0 220 150\" role=\"img\" aria-hidden=\"true\">\n            <rect x=\"38\" y=\"24\" width=\"144\" height=\"98\" rx=\"12\" class=\"empty-surface\"/>\n            <path d=\"M58 49h68M58 69h104M58 89h52\" class=\"empty-line\"/>\n            <circle cx=\"151\" cy=\"103\" r=\"27\" class=\"empty-accent\"/>\n            <path d=\"m171 123 18 18M141 103h20\" class=\"empty-icon\"/>\n          </svg>\n          <strong>{{ translateService.translate('datatable_empty_title') }}</strong><span>{{ translateService.translate('datatable_empty_description') }}</span>\n          <p-button type=\"button\" icon=\"pi pi-plus\" [disabled]=\"createDisabled\"\n                    [pTooltip]=\"createDisabled ? createDisabledReason : ''\" [outlined]=\"true\"\n                    [label]=\"translateService.translate('datatable_add_first')\" (onClick)=\"onRegisterData(null, 2)\"/>\n        </div>\n      }\n      <div #mobileSentinel class=\"datatable__mobile-sentinel\" aria-hidden=\"true\">@if (loading && config.values.length) {\n        <i class=\"pi pi-spin pi-spinner\"></i>\n      }</div>\n    </div>\n  </div>\n\n  <footer class=\"datatable__footer\">\n    <span class=\"datatable__count\">\n      {{ config.totalRecords }} {{ translateService.translate('datatable_records') }}\n    </span>\n    <p-paginator\n      (onPageChange)=\"pageChange($event)\"\n      [first]=\"(config.page - 1) * config.size\"\n      [rows]=\"config.size\"\n      [totalRecords]=\"config.totalRecords\"\n      [rowsPerPageOptions]=\"[10, 20, 30, 50]\"\n      appendTo=\"body\"\n      dropdownAppendTo=\"body\"/>\n  </footer>\n</div>\n\n<p-drawer [(visible)]=\"sidebarVisible\" position=\"right\" [modal]=\"false\" [blockScroll]=\"false\" [dismissible]=\"true\"\n          appendTo=\"body\" styleClass=\"datatable__filter-drawer\">\n  <ng-template pTemplate=\"header\">\n    <div class=\"datatable__drawer-title\">\n      <i class=\"pi pi-filter\"></i>\n      <span>{{ translateService.translate('datatable_filters') }}</span>\n    </div>\n  </ng-template>\n  <ng-template pTemplate=\"content\">\n    <div class=\"datatable__filter-form\">\n      <p class=\"datatable__filter-description\">{{ translateService.translate('datatable_filters_description') }}</p>\n      @for (filter of config.filters; track filter.key || filter.field) {\n        @if (filter.type === 'field-select') {\n          <sv-dropdown class=\"datatable__filter-field\" [(ngModel)]=\"filterValues[filter.key || filter.field]\"\n                        [name]=\"filter.key || filter.field\"\n                        [label]=\"translateService.translate(filter.label || filter.field)\"\n                        [options]=\"translatedOptions(filter.options)\" optionLabel=\"label\" optionValue=\"value\"/>\n        } @else if (filter.type === 'entity-select') {\n          <sv-auto-complete class=\"datatable__filter-field\" [(ngModel)]=\"filterValues[filter.key || filter.field]\"\n                             [name]=\"filter.key || filter.field\"\n                             [label]=\"translateService.translate(filter.label || filter.field)\"\n                             [route]=\"filter.route || ''\" [optionLabel]=\"filter.optionLabel || 'description'\"\n                             type=\"text\"/>\n        } @else if (filter.type === 'date') {\n          <sv-input-date class=\"datatable__filter-field\" [(ngModel)]=\"filterValues[filter.key || filter.field]\"\n                          [name]=\"filter.key || filter.field\"\n                          [label]=\"translateService.translate(filter.label || filter.field)\"/>\n        } @else {\n          <label class=\"datatable__filter-field\">\n            <span>{{ translateService.translate(filter.label || filter.field) }}</span>\n          @if (filter.type === 'select') {\n            <p-select [(ngModel)]=\"filterValues[filter.key || filter.field]\" [options]=\"translatedOptions(filter.options)\"\n                      optionLabel=\"label\" optionValue=\"value\" [showClear]=\"true\"\n                      [placeholder]=\"translateService.translate('datatable_all')\" appendTo=\"body\"/>\n          } @else {\n            <input pInputText [(ngModel)]=\"filterValues[filter.key || filter.field]\" type=\"text\"\n                   [placeholder]=\"translateService.translate('datatable_filter_by') + ' ' + translateService.translate(filter.label || filter.field).toLowerCase()\"/>\n          }\n          </label>\n        }\n      }\n      @if (!config.filters.length) {\n        <div class=\"datatable__filter-empty\"><i\n          class=\"pi pi-sliders-h\"></i><span>{{ translateService.translate('datatable_filters_description') }}</span>\n        </div>\n      }\n    </div>\n  </ng-template>\n  <ng-template pTemplate=\"footer\">\n    <div class=\"datatable__filter-actions\">\n      <p-button icon=\"pi pi-times\" [outlined]=\"true\" [label]=\"translateService.translate('datatable_clear')\"\n                (onClick)=\"onRefreshData()\"/>\n      <p-button icon=\"pi pi-check\" [label]=\"translateService.translate('datatable_apply_filters')\"\n                (onClick)=\"onApplyFilters()\"/>\n    </div>\n  </ng-template>\n</p-drawer>\n", styles: [":host{display:block;min-height:0;height:100%}.datatable{display:flex;flex-direction:column;min-height:32rem;height:100%;overflow:hidden;border:1px solid var(--p-content-border-color);border-radius:12px;background:var(--p-content-background)}.datatable__toolbar{display:flex;align-items:center;justify-content:space-between;flex:0 0 auto;gap:1rem;padding:.75rem 1rem;border-bottom:1px solid var(--p-content-border-color)}.datatable__search{width:min(22rem,42%)}.datatable__search input{width:100%;height:2.25rem;font-size:.8rem}.datatable__toolbar-actions,.datatable__row-actions{display:flex;align-items:center;gap:.5rem}.datatable__content{flex:1 1 auto;min-height:0;overflow:auto}.datatable__mobile-list{display:none}:host ::ng-deep .datatable__prime .p-datatable-table{table-layout:auto}:host ::ng-deep .datatable__prime .p-datatable-thead>tr>th{position:sticky;z-index:2;top:0;padding:.55rem .65rem;border-color:var(--p-content-border-color);background:var(--p-content-background);color:var(--p-text-muted-color);font-size:.68rem;font-weight:700;letter-spacing:.045em;text-transform:uppercase;white-space:nowrap}.datatable__sort{align-items:center;background:transparent;border:0;color:inherit;cursor:pointer;display:inline-flex;font:inherit;font-weight:inherit;gap:.4rem;letter-spacing:inherit;padding:0;text-transform:inherit}.datatable__sort i{font-size:.65rem;opacity:.45}.datatable__sort:hover,.datatable__sort.is-active{color:var(--p-primary-color)}.datatable__sort.is-active i{opacity:1}:host ::ng-deep .datatable__prime .p-datatable-tbody>tr>td{max-width:22rem;padding:.48rem .65rem;border-color:var(--p-content-border-color);color:var(--p-text-color);font-size:.76rem;line-height:1.25;vertical-align:middle}:host ::ng-deep .datatable__prime .p-datatable-tbody>tr:hover>td{background:color-mix(in srgb,var(--p-primary-color),transparent 96%)}.datatable__cell-value{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.datatable__select{width:2.5rem;min-width:2.5rem;text-align:center}.datatable__actions-column{width:5.5rem;min-width:5.5rem;text-align:center}.datatable__row-actions{justify-content:center;gap:.15rem}:host ::ng-deep .datatable__row-actions .p-button{width:1.9rem;height:1.9rem;padding:0}.datatable__empty-cell{height:clamp(19rem,48vh,32rem);border:0}.datatable__empty{display:flex;align-items:center;justify-content:center;flex-direction:column;height:100%;padding:2rem;text-align:center}.datatable__empty svg{width:min(13rem,48vw);margin-bottom:.75rem}.empty-surface{fill:var(--p-form-field-background);stroke:var(--p-content-border-color);stroke-width:2}.empty-line{fill:none;stroke:var(--p-text-muted-color);stroke-linecap:round;stroke-width:5;opacity:.45}.empty-accent{fill:color-mix(in srgb,var(--p-primary-color),transparent 82%);stroke:var(--p-primary-color);stroke-width:3}.empty-icon{fill:none;stroke:var(--p-primary-color);stroke-linecap:round;stroke-width:5}.datatable__empty strong{margin-bottom:.35rem;font-size:1rem;font-weight:650}.datatable__empty span{max-width:26rem;margin-bottom:1.25rem;color:var(--p-text-muted-color);font-size:.8rem}.datatable__footer{display:flex;align-items:center;justify-content:space-between;flex:0 0 auto;min-height:3.25rem;padding:.25rem .75rem .25rem 1rem;border-top:1px solid var(--p-content-border-color);background:var(--p-content-background)}.datatable__count{color:var(--p-text-muted-color);font-size:.72rem;white-space:nowrap}:host ::ng-deep .datatable__footer .p-paginator{padding:0;background:transparent;font-size:.75rem}:host ::ng-deep .datatable__footer .p-paginator-page,:host ::ng-deep .datatable__footer .p-paginator-next,:host ::ng-deep .datatable__footer .p-paginator-prev,:host ::ng-deep .datatable__footer .p-paginator-first,:host ::ng-deep .datatable__footer .p-paginator-last{min-width:2rem;height:2rem}.datatable__drawer-title{display:flex;align-items:center;gap:.75rem;font-size:1.1rem;font-weight:600}.datatable__filter-form{display:flex;flex-direction:column;gap:1.25rem}.datatable__filter-description{margin:0;color:var(--p-text-muted-color);font-size:.8rem;line-height:1.5}.datatable__filter-field{display:flex;flex-direction:column;gap:.5rem}.datatable__filter-field>span{font-size:.78rem;font-weight:600}.datatable__filter-field>input{width:100%}:host ::ng-deep .datatable__filter-field .p-select{width:100%}:host ::ng-deep sv-auto-complete.datatable__filter-field .p-autocomplete,:host ::ng-deep sv-input-date.datatable__filter-field .p-datepicker,:host ::ng-deep sv-dropdown.datatable__filter-field .p-select{width:100%}.datatable__filter-actions{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}:host ::ng-deep .datatable__filter-actions .p-button{width:100%}.datatable__filter-empty{display:flex;align-items:center;flex-direction:column;gap:1rem;padding:3rem 1rem;color:var(--p-text-muted-color);text-align:center}.datatable__filter-empty i{font-size:2rem;color:var(--p-primary-color)}@media(max-width:768px){.datatable{min-height:28rem;border-right:0;border-left:0;border-radius:0}.datatable__toolbar{align-items:stretch;flex-direction:column}.datatable__search{width:100%}.datatable__toolbar-actions{justify-content:flex-end}.datatable__toolbar-actions p-button:last-child{flex:1}:host ::ng-deep .datatable__toolbar-actions p-button:last-child .p-button{width:100%}:host ::ng-deep .datatable__prime{display:none}.datatable__mobile-list{display:flex;flex-direction:column;gap:.65rem;padding:.75rem}.datatable__mobile-card{display:flex;align-items:center;gap:.75rem;padding:.85rem .6rem .85rem .9rem;border:1px solid var(--p-content-border-color);border-radius:10px;background:var(--p-content-background)}.datatable__mobile-fields{display:grid;flex:1;min-width:0;gap:.55rem}.datatable__mobile-field{display:flex;min-width:0;flex-direction:column;gap:.15rem}.datatable__mobile-field span{color:var(--p-text-muted-color);font-size:.65rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase}.datatable__mobile-field strong{overflow:hidden;color:var(--p-text-color);font-size:.85rem;font-weight:550;text-overflow:ellipsis;white-space:nowrap}.datatable__mobile-actions{display:flex;flex:0 0 auto}.datatable__mobile-empty{min-height:22rem}.datatable__mobile-sentinel{display:flex;align-items:center;justify-content:center;min-height:2.5rem;color:var(--p-primary-color)}.datatable__footer{align-items:flex-start;flex-direction:column;gap:.25rem;padding:.5rem .75rem}:host ::ng-deep .datatable__footer .p-paginator{display:none}}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.ConfirmationService }, { type: TranslateService }, { type: i1.DatePipe }, { type: i4$3.Router }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SMARTVERSE_COMPONENTS_CONFIG]
                }] }], propDecorators: { config: [{
                type: Input
            }], loading: [{
                type: Input
            }], createDisabled: [{
                type: Input
            }], createDisabledReason: [{
                type: Input
            }], mobileSentinel: [{
                type: ViewChild,
                args: ['mobileSentinel']
            }], onRegister: [{
                type: Output
            }], onRefresh: [{
                type: Output
            }] } });

class ImageUploadService {
    http;
    config;
    constructor(http, config) {
        this.http = http;
        this.config = config;
    }
    onRequestUpload(imageName) {
        return this.http.get(this.config.endpoints.requestUpload, { params: this.params(imageName) });
    }
    onRequestDonwload(imageName) {
        return this.http.get(this.config.endpoints.requestDownload, { params: this.params(imageName) });
    }
    onDeleteObject(imageName) {
        return this.http.get(this.config.endpoints.deleteObject, { params: new HttpParams().set('fileName', imageName) });
    }
    onUpload(url, file) {
        const headers = new HttpHeaders({
            'Content-Type': 'application/octet-stream', // Define o tipo como binário
        });
        return this.http.put(url, file, { headers });
    }
    params(fileName) {
        return new HttpParams().set('fileName', fileName).set('expired', '10000');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ImageUploadService, deps: [{ token: i1$1.HttpClient }, { token: SMARTVERSE_COMPONENTS_CONFIG }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ImageUploadService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ImageUploadService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SMARTVERSE_COMPONENTS_CONFIG]
                }] }] });

function generateUUIDv4() {
    return globalThis.crypto?.randomUUID?.() ?? 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, value => {
        const random = Math.floor(Math.random() * 16);
        return (value === 'x' ? random : (random & 0x3) | 0x8).toString(16);
    });
}
function base64ToArrayBuffer(base64) {
    const binary = atob(base64.split(',')[1] ?? '');
    return Uint8Array.from(binary, character => character.charCodeAt(0)).buffer;
}

class ImageUploadComponent extends AppControlValueAccessor {
    imageUploadService;
    toastService;
    fieldServiceInputText;
    _image = null;
    imageUrl = null;
    tokenImageUrl = "";
    ownerId = "";
    cropAspectRatio;
    cropResizeWidth = 1600;
    eventLoading = new EventEmitter();
    eventImageToken = new EventEmitter();
    imageChangedEvent = null;
    croppedImage = null;
    cropVisible = false;
    constructor(imageUploadService, toastService, fieldServiceInputText) {
        super(fieldServiceInputText);
        this.imageUploadService = imageUploadService;
        this.toastService = toastService;
        this.fieldServiceInputText = fieldServiceInputText;
    }
    onFileInput(fileInput) {
        fileInput?.click();
    }
    onImageSelect(event) {
        const file = event.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                this._image = null;
                this.imageUrl = "";
            }
            else if (this.cropAspectRatio) {
                this.imageChangedEvent = event;
                this.croppedImage = null;
                this.cropVisible = true;
            }
            else {
                this._image = file;
                const reader = new FileReader();
                reader.onload = () => {
                    this.onShowLoading();
                    if (this._image) {
                        const imageId = generateUUIDv4().toUpperCase();
                        const extension = this.imageExtension(this._image.name);
                        const folder = this.ownerId || imageId;
                        this.tokenImageUrl = `${folder}/${imageId}${extension}`;
                        this.imageUploadService.onRequestUpload(this.tokenImageUrl).subscribe({
                            next: (res) => {
                                const arr = base64ToArrayBuffer(String(reader.result ?? ''));
                                this.onSendAws(res.url, arr);
                            },
                            error: (err) => {
                                this.onShowLoading();
                            }
                        });
                    }
                };
                reader.readAsDataURL(file);
            }
        }
    }
    onImageCropped(event) {
        this.croppedImage = event.blob ?? null;
    }
    cancelCrop(fileInput) {
        this.cropVisible = false;
        this.imageChangedEvent = null;
        this.croppedImage = null;
        if (fileInput)
            fileInput.value = '';
    }
    async confirmCrop(fileInput) {
        if (!this.croppedImage)
            return;
        const imageId = generateUUIDv4().toUpperCase();
        const folder = this.ownerId || imageId;
        this.tokenImageUrl = `${folder}/${imageId}.jpg`;
        const buffer = await this.croppedImage.arrayBuffer();
        this.cropVisible = false;
        this.imageChangedEvent = null;
        this.croppedImage = null;
        if (fileInput)
            fileInput.value = '';
        this.onShowLoading();
        this.imageUploadService.onRequestUpload(this.tokenImageUrl).subscribe({
            next: res => this.onSendAws(res.url, buffer),
            error: () => this.onShowLoading()
        });
    }
    imageExtension(fileName) {
        const lastDot = fileName.lastIndexOf(".");
        if (lastDot <= 0 || lastDot === fileName.length - 1)
            return "";
        return fileName.substring(lastDot).toLowerCase().replace(/[^.a-z0-9]/g, "");
    }
    onSendAws(url, arrayBuffer) {
        this.imageUploadService.onUpload(url, arrayBuffer).subscribe({
            next: (res) => {
                this.onRequestDonwload();
            },
            error: (err) => {
                this.onShowLoading();
            }
        });
    }
    onRequestDonwload() {
        this.imageUploadService.onRequestDonwload(this.tokenImageUrl).subscribe({
            next: (res) => {
                this.imageUrl = res.url;
                this.onShowLoading();
                this.onImageToken();
            },
            error: (err) => {
                this.onShowLoading();
            }
        });
    }
    onDeleteImage() {
        this.onShowLoading();
        if (this.tokenImageUrl !== "") {
            this.imageUploadService.onDeleteObject(this.tokenImageUrl).subscribe({
                next: (res) => {
                    this.tokenImageUrl = "";
                    this._image = null;
                    this.imageUrl = null;
                    this.onImageToken();
                    this.onShowLoading();
                    this.toastService.success({ summary: "Imagem", detail: "Imagem excluída com sucesso" });
                },
                error: (err) => {
                    this.onShowLoading();
                }
            });
        }
    }
    onShowLoading() {
        this.eventLoading.emit();
    }
    onImageToken() {
        this.eventImageToken.emit(this.tokenImageUrl);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ImageUploadComponent, deps: [{ token: ImageUploadService }, { token: ToastService }, { token: FieldsService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: ImageUploadComponent, isStandalone: true, selector: "sv-image-upload", inputs: { imageUrl: "imageUrl", tokenImageUrl: "tokenImageUrl", ownerId: "ownerId", cropAspectRatio: "cropAspectRatio", cropResizeWidth: "cropResizeWidth" }, outputs: { eventLoading: "eventLoading", eventImageToken: "eventImageToken" }, providers: [
            ImageUploadService,
            { provide: NG_VALUE_ACCESSOR, useExisting: ImageUploadComponent, multi: true }
        ], usesInheritance: true, ngImport: i0, template: "<div class=\"image-upload\">\n  <button\n    type=\"button\"\n    class=\"image-upload__preview\"\n    (click)=\"onFileInput(fileInput)\"\n    aria-label=\"Selecionar foto\">\n    @if (imageUrl) {\n      <img [src]=\"imageUrl\" alt=\"Foto selecionada\">\n      <span class=\"image-upload__overlay\">\n        <i class=\"pi pi-camera\"></i>\n        Alterar foto\n      </span>\n    } @else {\n      <span class=\"image-upload__placeholder\">\n        <span class=\"image-upload__icon\"><i class=\"pi pi-camera\"></i></span>\n        <strong>Adicionar foto</strong>\n        <small>JPG ou PNG, at\u00E9 5 MB</small>\n      </span>\n    }\n  </button>\n\n  <input\n    #fileInput\n    type=\"file\"\n    (change)=\"onImageSelect($event)\"\n    accept=\"image/*\"\n    class=\"file-input\" />\n\n  <div class=\"image-upload__actions\">\n    <button\n      type=\"button\"\n      pButton\n      pRipple\n      class=\"p-button-outlined image-upload__select\"\n      icon=\"pi pi-upload\"\n      [label]=\"imageUrl ? 'Substituir' : 'Selecionar'\"\n      (click)=\"onFileInput(fileInput)\">\n    </button>\n    @if (imageUrl) {\n      <button\n        type=\"button\"\n        pButton\n        pRipple\n        class=\"p-button-outlined p-button-danger image-upload__delete\"\n        icon=\"pi pi-trash\"\n        aria-label=\"Remover foto\"\n        (click)=\"onDeleteImage()\">\n      </button>\n    }\n  </div>\n\n  @if (cropVisible) {\n    <div class=\"crop-dialog\" role=\"dialog\" aria-modal=\"true\" aria-label=\"Recortar imagem\">\n      <div class=\"crop-dialog__backdrop\" (click)=\"cancelCrop(fileInput)\"></div>\n      <section class=\"crop-dialog__panel\">\n        <header><div><strong>Ajustar imagem</strong><small>Arraste e redimensione para escolher o enquadramento.</small></div><button type=\"button\" aria-label=\"Fechar\" (click)=\"cancelCrop(fileInput)\"><i class=\"pi pi-times\"></i></button></header>\n        <div class=\"crop-dialog__canvas\">\n          <image-cropper\n            [imageChangedEvent]=\"imageChangedEvent\"\n            [maintainAspectRatio]=\"true\"\n            [aspectRatio]=\"cropAspectRatio || 1\"\n            [resizeToWidth]=\"cropResizeWidth\"\n            [onlyScaleDown]=\"true\"\n            output=\"blob\"\n            format=\"jpeg\"\n            (imageCropped)=\"onImageCropped($event)\" />\n        </div>\n        <footer><button type=\"button\" pButton class=\"p-button-outlined\" label=\"Cancelar\" (click)=\"cancelCrop(fileInput)\"></button><button type=\"button\" pButton label=\"Usar este recorte\" icon=\"pi pi-check\" [disabled]=\"!croppedImage\" (click)=\"confirmCrop(fileInput)\"></button></footer>\n      </section>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.image-upload{width:100%}.crop-dialog{position:fixed;inset:0;z-index:10000;display:grid;place-items:center;padding:1rem}.crop-dialog__backdrop{position:absolute;inset:0;background:#0f172ab8;-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px)}.crop-dialog__panel{position:relative;width:min(900px,96vw);max-height:92vh;overflow:auto;border-radius:16px;background:var(--p-content-background);box-shadow:0 24px 70px #00000059}.crop-dialog__panel header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.25rem;border-bottom:1px solid var(--p-content-border-color)}.crop-dialog__panel header div{display:grid;gap:.2rem}.crop-dialog__panel header small{color:var(--p-text-muted-color)}.crop-dialog__panel header button{border:0;background:transparent;color:var(--p-text-color);font-size:1.1rem;cursor:pointer}.crop-dialog__canvas{height:min(62vh,560px);padding:1rem;background:#111827}.crop-dialog__canvas image-cropper{height:100%;max-height:100%}.crop-dialog__panel footer{display:flex;justify-content:flex-end;gap:.75rem;padding:1rem 1.25rem;border-top:1px solid var(--p-content-border-color)}.image-upload__preview{position:relative;display:block;width:100%;aspect-ratio:1;overflow:hidden;padding:0;border:1px dashed var(--p-content-border-color);border-radius:12px;background:var(--p-form-field-background);color:var(--p-text-muted-color);cursor:pointer;transition:border-color .2s,box-shadow .2s,background .2s}.image-upload__preview:hover,.image-upload__preview:focus-visible{border-color:var(--p-primary-color);background:color-mix(in srgb,var(--p-primary-color),transparent 96%);box-shadow:0 0 0 3px color-mix(in srgb,var(--p-primary-color),transparent 86%);outline:0}.image-upload__preview img{display:block;width:100%;height:100%;object-fit:cover}.image-upload__placeholder{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:.5rem;padding:1rem;text-align:center}.image-upload__placeholder strong{color:var(--p-text-color);font-size:.95rem;font-weight:600}.image-upload__placeholder small{color:var(--p-text-muted-color);font-size:.75rem}.image-upload__icon{display:grid;width:3rem;height:3rem;place-items:center;margin-bottom:.25rem;border-radius:10px;background:color-mix(in srgb,var(--p-primary-color),transparent 88%);color:var(--p-primary-color);font-size:1.25rem}.image-upload__overlay{position:absolute;right:0;bottom:0;left:0;display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.75rem;background:color-mix(in srgb,var(--p-content-background),transparent 12%);color:var(--p-text-color);font-size:.8rem;font-weight:600;opacity:0;transform:translateY(100%);transition:opacity .2s,transform .2s}.image-upload__preview:hover .image-upload__overlay,.image-upload__preview:focus-visible .image-upload__overlay{opacity:1;transform:translateY(0)}.file-input{display:none}.image-upload__actions{display:flex;gap:.5rem;margin-top:.75rem}.image-upload__select{flex:1}.image-upload__delete{flex:0 0 auto}:host ::ng-deep .image-upload__select .p-button-label{flex:initial}\n"], dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i4.ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "pButtonPT", "pButtonUnstyled", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "component", type: ImageCropperComponent, selector: "image-cropper", inputs: ["imageChangedEvent", "imageURL", "imageBase64", "imageFile", "imageAltText", "options", "cropperFrameAriaLabel", "output", "format", "autoCrop", "cropper", "transform", "maintainAspectRatio", "aspectRatio", "resetCropOnAspectRatioChange", "resizeToWidth", "resizeToHeight", "cropperMinWidth", "cropperMinHeight", "cropperMaxHeight", "cropperMaxWidth", "cropperStaticWidth", "cropperStaticHeight", "canvasRotation", "initialStepSize", "roundCropper", "onlyScaleDown", "imageQuality", "backgroundColor", "containWithinAspectRatio", "hideResizeSquares", "allowMoveImage", "checkImageType", "alignImage", "disabled", "hidden"], outputs: ["imageCropped", "startCropImage", "imageLoaded", "cropperReady", "loadImageFailed", "transformChange", "cropperChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ImageUploadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-image-upload', imports: [
                        ButtonModule,
                        Ripple,
                        ImageCropperComponent,
                    ], providers: [
                        ImageUploadService,
                        { provide: NG_VALUE_ACCESSOR, useExisting: ImageUploadComponent, multi: true }
                    ], template: "<div class=\"image-upload\">\n  <button\n    type=\"button\"\n    class=\"image-upload__preview\"\n    (click)=\"onFileInput(fileInput)\"\n    aria-label=\"Selecionar foto\">\n    @if (imageUrl) {\n      <img [src]=\"imageUrl\" alt=\"Foto selecionada\">\n      <span class=\"image-upload__overlay\">\n        <i class=\"pi pi-camera\"></i>\n        Alterar foto\n      </span>\n    } @else {\n      <span class=\"image-upload__placeholder\">\n        <span class=\"image-upload__icon\"><i class=\"pi pi-camera\"></i></span>\n        <strong>Adicionar foto</strong>\n        <small>JPG ou PNG, at\u00E9 5 MB</small>\n      </span>\n    }\n  </button>\n\n  <input\n    #fileInput\n    type=\"file\"\n    (change)=\"onImageSelect($event)\"\n    accept=\"image/*\"\n    class=\"file-input\" />\n\n  <div class=\"image-upload__actions\">\n    <button\n      type=\"button\"\n      pButton\n      pRipple\n      class=\"p-button-outlined image-upload__select\"\n      icon=\"pi pi-upload\"\n      [label]=\"imageUrl ? 'Substituir' : 'Selecionar'\"\n      (click)=\"onFileInput(fileInput)\">\n    </button>\n    @if (imageUrl) {\n      <button\n        type=\"button\"\n        pButton\n        pRipple\n        class=\"p-button-outlined p-button-danger image-upload__delete\"\n        icon=\"pi pi-trash\"\n        aria-label=\"Remover foto\"\n        (click)=\"onDeleteImage()\">\n      </button>\n    }\n  </div>\n\n  @if (cropVisible) {\n    <div class=\"crop-dialog\" role=\"dialog\" aria-modal=\"true\" aria-label=\"Recortar imagem\">\n      <div class=\"crop-dialog__backdrop\" (click)=\"cancelCrop(fileInput)\"></div>\n      <section class=\"crop-dialog__panel\">\n        <header><div><strong>Ajustar imagem</strong><small>Arraste e redimensione para escolher o enquadramento.</small></div><button type=\"button\" aria-label=\"Fechar\" (click)=\"cancelCrop(fileInput)\"><i class=\"pi pi-times\"></i></button></header>\n        <div class=\"crop-dialog__canvas\">\n          <image-cropper\n            [imageChangedEvent]=\"imageChangedEvent\"\n            [maintainAspectRatio]=\"true\"\n            [aspectRatio]=\"cropAspectRatio || 1\"\n            [resizeToWidth]=\"cropResizeWidth\"\n            [onlyScaleDown]=\"true\"\n            output=\"blob\"\n            format=\"jpeg\"\n            (imageCropped)=\"onImageCropped($event)\" />\n        </div>\n        <footer><button type=\"button\" pButton class=\"p-button-outlined\" label=\"Cancelar\" (click)=\"cancelCrop(fileInput)\"></button><button type=\"button\" pButton label=\"Usar este recorte\" icon=\"pi pi-check\" [disabled]=\"!croppedImage\" (click)=\"confirmCrop(fileInput)\"></button></footer>\n      </section>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.image-upload{width:100%}.crop-dialog{position:fixed;inset:0;z-index:10000;display:grid;place-items:center;padding:1rem}.crop-dialog__backdrop{position:absolute;inset:0;background:#0f172ab8;-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px)}.crop-dialog__panel{position:relative;width:min(900px,96vw);max-height:92vh;overflow:auto;border-radius:16px;background:var(--p-content-background);box-shadow:0 24px 70px #00000059}.crop-dialog__panel header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.25rem;border-bottom:1px solid var(--p-content-border-color)}.crop-dialog__panel header div{display:grid;gap:.2rem}.crop-dialog__panel header small{color:var(--p-text-muted-color)}.crop-dialog__panel header button{border:0;background:transparent;color:var(--p-text-color);font-size:1.1rem;cursor:pointer}.crop-dialog__canvas{height:min(62vh,560px);padding:1rem;background:#111827}.crop-dialog__canvas image-cropper{height:100%;max-height:100%}.crop-dialog__panel footer{display:flex;justify-content:flex-end;gap:.75rem;padding:1rem 1.25rem;border-top:1px solid var(--p-content-border-color)}.image-upload__preview{position:relative;display:block;width:100%;aspect-ratio:1;overflow:hidden;padding:0;border:1px dashed var(--p-content-border-color);border-radius:12px;background:var(--p-form-field-background);color:var(--p-text-muted-color);cursor:pointer;transition:border-color .2s,box-shadow .2s,background .2s}.image-upload__preview:hover,.image-upload__preview:focus-visible{border-color:var(--p-primary-color);background:color-mix(in srgb,var(--p-primary-color),transparent 96%);box-shadow:0 0 0 3px color-mix(in srgb,var(--p-primary-color),transparent 86%);outline:0}.image-upload__preview img{display:block;width:100%;height:100%;object-fit:cover}.image-upload__placeholder{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:.5rem;padding:1rem;text-align:center}.image-upload__placeholder strong{color:var(--p-text-color);font-size:.95rem;font-weight:600}.image-upload__placeholder small{color:var(--p-text-muted-color);font-size:.75rem}.image-upload__icon{display:grid;width:3rem;height:3rem;place-items:center;margin-bottom:.25rem;border-radius:10px;background:color-mix(in srgb,var(--p-primary-color),transparent 88%);color:var(--p-primary-color);font-size:1.25rem}.image-upload__overlay{position:absolute;right:0;bottom:0;left:0;display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.75rem;background:color-mix(in srgb,var(--p-content-background),transparent 12%);color:var(--p-text-color);font-size:.8rem;font-weight:600;opacity:0;transform:translateY(100%);transition:opacity .2s,transform .2s}.image-upload__preview:hover .image-upload__overlay,.image-upload__preview:focus-visible .image-upload__overlay{opacity:1;transform:translateY(0)}.file-input{display:none}.image-upload__actions{display:flex;gap:.5rem;margin-top:.75rem}.image-upload__select{flex:1}.image-upload__delete{flex:0 0 auto}:host ::ng-deep .image-upload__select .p-button-label{flex:initial}\n"] }]
        }], ctorParameters: () => [{ type: ImageUploadService }, { type: ToastService }, { type: FieldsService }], propDecorators: { imageUrl: [{
                type: Input
            }], tokenImageUrl: [{
                type: Input
            }], ownerId: [{
                type: Input
            }], cropAspectRatio: [{
                type: Input
            }], cropResizeWidth: [{
                type: Input
            }], eventLoading: [{
                type: Output
            }], eventImageToken: [{
                type: Output
            }] } });

class InputMaskComponent extends AppControlValueAccessor {
    fieldServiceInputText;
    mask = "";
    blurred = new EventEmitter();
    constructor(fieldServiceInputText) {
        super(fieldServiceInputText);
        this.fieldServiceInputText = fieldServiceInputText;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputMaskComponent, deps: [{ token: FieldsService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: InputMaskComponent, isStandalone: true, selector: "sv-input-mask", inputs: { mask: "mask" }, outputs: { blurred: "blurred" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: InputMaskComponent,
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "\n<p-floatLabel>\n  <p-inputMask\n    [pTooltip]=\"guidance\"\n    (ngModelChange)=\"onChange($event)\"\n    (onBlur)=\"blurred.emit()\"\n    [ngModel]=\"value\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    class=\"w-full outlined\"\n      [pAutoFocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [mask]=\"mask\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n", styles: [":host{display:block;width:100%;min-width:0}p-floatLabel{display:block;width:100%}:host::ng-deep .p-inputmask,:host::ng-deep .p-inputtext{width:100%;max-width:100%;box-sizing:border-box}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: InputMaskModule }, { kind: "component", type: i3$2.InputMask, selector: "p-inputmask, p-inputMask, p-input-mask", inputs: ["type", "slotChar", "autoClear", "showClear", "style", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabel", "ariaLabelledBy", "ariaRequired", "readonly", "unmask", "characterPattern", "autofocus", "autocomplete", "keepBuffer", "mask"], outputs: ["onComplete", "onFocus", "onBlur", "onInput", "onKeydown", "onClear"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i6$2.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "ngmodule", type: AutoFocusModule }, { kind: "directive", type: i6.AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "ngmodule", type: AutoCompleteModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputMaskComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-input-mask', imports: [
                        CommonModule,
                        InputMaskModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FloatLabelModule,
                        TooltipModule,
                        AutoFocusModule,
                        AutoCompleteModule
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: InputMaskComponent,
                            multi: true
                        }
                    ], template: "\n<p-floatLabel>\n  <p-inputMask\n    [pTooltip]=\"guidance\"\n    (ngModelChange)=\"onChange($event)\"\n    (onBlur)=\"blurred.emit()\"\n    [ngModel]=\"value\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    class=\"w-full outlined\"\n      [pAutoFocus]=\"focus\"\n    [disabled]=\"disabled\"\n    [mask]=\"mask\"/>\n  <label>{{label}}</label>\n</p-floatLabel>\n", styles: [":host{display:block;width:100%;min-width:0}p-floatLabel{display:block;width:100%}:host::ng-deep .p-inputmask,:host::ng-deep .p-inputtext{width:100%;max-width:100%;box-sizing:border-box}\n"] }]
        }], ctorParameters: () => [{ type: FieldsService }], propDecorators: { mask: [{
                type: Input
            }], blurred: [{
                type: Output
            }] } });

class InputNumberComponent extends AppControlValueAccessor {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputNumberComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: InputNumberComponent, isStandalone: true, selector: "sv-input-number", providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: InputNumberComponent,
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "<p-floatLabel>\n  <p-inputNumber\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    class=\"p-inputnumber\"\n    [pTooltip]=\"guidance\"\n    inputId=\"minmaxfraction\"\n    mode=\"decimal\"\n    [disabled]=\"disabled\"\n      [pAutoFocus]=\"focus\"\n    [minFractionDigits]=\"2\"\n    [maxFractionDigits]=\"5\" />\n  <label id=\"\">{{label}}</label>\n</p-floatLabel>\n", styles: [":host::ng-deep p-inputnumber,:host::ng-deep .p-inputnumber{width:100%!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i6$2.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "ngmodule", type: InputNumberModule }, { kind: "component", type: i5$2.InputNumber, selector: "p-inputNumber, p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "ngmodule", type: AutoFocusModule }, { kind: "directive", type: i6.AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "ngmodule", type: AutoCompleteModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputNumberComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-input-number', imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FloatLabelModule,
                        TooltipModule,
                        InputNumberModule,
                        AutoFocusModule,
                        AutoCompleteModule
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: InputNumberComponent,
                            multi: true
                        }
                    ], template: "<p-floatLabel>\n  <p-inputNumber\n    (ngModelChange)=\"onChange($event)\"\n    [ngModel]=\"value\"\n    [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n    class=\"p-inputnumber\"\n    [pTooltip]=\"guidance\"\n    inputId=\"minmaxfraction\"\n    mode=\"decimal\"\n    [disabled]=\"disabled\"\n      [pAutoFocus]=\"focus\"\n    [minFractionDigits]=\"2\"\n    [maxFractionDigits]=\"5\" />\n  <label id=\"\">{{label}}</label>\n</p-floatLabel>\n", styles: [":host::ng-deep p-inputnumber,:host::ng-deep .p-inputnumber{width:100%!important}\n"] }]
        }] });

class InputTextComponent extends AppControlValueAccessor {
    fieldServiceInputText;
    fieldType = "input-text";
    constructor(fieldServiceInputText) {
        super(fieldServiceInputText);
        this.fieldServiceInputText = fieldServiceInputText;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputTextComponent, deps: [{ token: FieldsService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: InputTextComponent, isStandalone: true, selector: "sv-input-text", inputs: { fieldType: "fieldType" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: InputTextComponent,
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "\n<p-floatLabel>\n  @if (fieldType === 'input-text') {\n    <input  [type]=\"type\"\n      [pTooltip]=\"guidance\"\n      [pAutoFocus]=\"focus\"\n      [disabled]=\"disabled\"\n      [autofocus]=\"focus\"\n      pInputText\n      (ngModelChange)=\"onChange($event)\"\n      [ngModel]=\"value\"\n      [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n      class=\"w-full outlined\"/>\n  }\n  @if (fieldType === 'input-text-area') {\n    <textarea\n      [pTooltip]=\"guidance\"\n      rows=\"5\"\n      cols=\"30\"\n      [pAutoFocus]=\"focus\"\n      [autoResize]=\"true\"\n      pTextarea\n      (ngModelChange)=\"onChange($event)\"\n      [ngModel]=\"value\"\n      [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n      class=\"w-full outlined\">\n    </textarea>\n  }\n  <label id=\"\">{{label}}</label>\n</p-floatLabel>\n\n", styles: [""], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i10.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i6$2.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "ngmodule", type: TextareaModule }, { kind: "directive", type: i7$1.Textarea, selector: "[pTextarea], [pInputTextarea]", inputs: ["pTextareaPT", "pTextareaUnstyled", "autoResize", "pSize", "variant", "fluid", "invalid"], outputs: ["onResize"] }, { kind: "ngmodule", type: AutoFocusModule }, { kind: "directive", type: i6.AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "ngmodule", type: AutoCompleteModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: InputTextComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-input-text', imports: [
                        CommonModule,
                        InputTextModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FloatLabelModule,
                        TooltipModule,
                        TextareaModule,
                        AutoFocusModule,
                        AutoCompleteModule
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: InputTextComponent,
                            multi: true
                        }
                    ], template: "\n<p-floatLabel>\n  @if (fieldType === 'input-text') {\n    <input  [type]=\"type\"\n      [pTooltip]=\"guidance\"\n      [pAutoFocus]=\"focus\"\n      [disabled]=\"disabled\"\n      [autofocus]=\"focus\"\n      pInputText\n      (ngModelChange)=\"onChange($event)\"\n      [ngModel]=\"value\"\n      [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n      class=\"w-full outlined\"/>\n  }\n  @if (fieldType === 'input-text-area') {\n    <textarea\n      [pTooltip]=\"guidance\"\n      rows=\"5\"\n      cols=\"30\"\n      [pAutoFocus]=\"focus\"\n      [autoResize]=\"true\"\n      pTextarea\n      (ngModelChange)=\"onChange($event)\"\n      [ngModel]=\"value\"\n      [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\"\n      class=\"w-full outlined\">\n    </textarea>\n  }\n  <label id=\"\">{{label}}</label>\n</p-floatLabel>\n\n" }]
        }], ctorParameters: () => [{ type: FieldsService }], propDecorators: { fieldType: [{
                type: Input
            }] } });

class MultiSelectComponent extends AppControlValueAccessor {
    crud;
    options = [];
    optionLabel = 'name';
    dataKey = 'id';
    route = '';
    defaultFilter = '';
    filter = true;
    display = 'chip';
    pageSize = 100;
    constructor(fields, crud) {
        super(fields);
        this.crud = crud;
    }
    ngOnInit() {
        super.ngOnInit();
        if (!this.route)
            return;
        const request = new RequestData();
        request.offset = 0;
        request.size = this.pageSize;
        request.filter = this.defaultFilter;
        this.crud.onGetAll(this.route, request).subscribe({ next: response => this.options = response.contents ?? [], error: () => this.options = [] });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MultiSelectComponent, deps: [{ token: FieldsService }, { token: CrudService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MultiSelectComponent, isStandalone: true, selector: "sv-multi-select", inputs: { options: "options", optionLabel: "optionLabel", dataKey: "dataKey", route: "route", defaultFilter: "defaultFilter", filter: "filter", display: "display", pageSize: "pageSize" }, providers: [CrudService, { provide: NG_VALUE_ACCESSOR, useExisting: MultiSelectComponent, multi: true }], usesInheritance: true, ngImport: i0, template: "<p-floatLabel>\n  <p-multiSelect (ngModelChange)=\"onChange($event)\" [ngModel]=\"value\" [options]=\"options\" [optionLabel]=\"optionLabel\" [dataKey]=\"dataKey\" [display]=\"display\" [filter]=\"filter\" [disabled]=\"disabled\" appendTo=\"body\" class=\"w-full\" styleClass=\"w-full\" [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\" />\n  <label>{{ label }}</label>\n</p-floatLabel>\n", styles: [":host,p-floatLabel{display:block;width:100%}:host ::ng-deep .p-multiselect{width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: FloatLabelModule }, { kind: "component", type: i5$1.FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: MultiSelectModule }, { kind: "component", type: i6$3.MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MultiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-multi-select', imports: [CommonModule, FormsModule, ReactiveFormsModule, FloatLabelModule, MultiSelectModule], providers: [CrudService, { provide: NG_VALUE_ACCESSOR, useExisting: MultiSelectComponent, multi: true }], template: "<p-floatLabel>\n  <p-multiSelect (ngModelChange)=\"onChange($event)\" [ngModel]=\"value\" [options]=\"options\" [optionLabel]=\"optionLabel\" [dataKey]=\"dataKey\" [display]=\"display\" [filter]=\"filter\" [disabled]=\"disabled\" appendTo=\"body\" class=\"w-full\" styleClass=\"w-full\" [ngClass]=\"{'ng-invalid ng-dirty': !isValid}\" />\n  <label>{{ label }}</label>\n</p-floatLabel>\n", styles: [":host,p-floatLabel{display:block;width:100%}:host ::ng-deep .p-multiselect{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: FieldsService }, { type: CrudService }], propDecorators: { options: [{
                type: Input
            }], optionLabel: [{
                type: Input
            }], dataKey: [{
                type: Input
            }], route: [{
                type: Input
            }], defaultFilter: [{
                type: Input
            }], filter: [{
                type: Input
            }], display: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

class LoadingComponent {
    showLoading = false;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoadingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: LoadingComponent, isStandalone: true, selector: "sv-loading", inputs: { showLoading: "showLoading" }, ngImport: i0, template: "@if (showLoading) {\n  <div class=\"loading\">\n    <div class=\"loader\"></div>\n  </div>\n}", styles: [".loading{width:100vw;height:100vh;z-index:9999999;position:absolute;background-color:#fffcfccc;display:flex;align-items:center;justify-content:center}.loader{width:50px;aspect-ratio:1;border:2px solid;box-sizing:border-box;border-radius:50%;display:grid;animation:l11 1.5s infinite linear;transform-origin:50% 80%}.loader:before,.loader:after{content:\"\";grid-area:1/1;border:inherit;border-radius:50%;animation:inherit;animation-duration:1s;transform-origin:inherit}.loader:after{--s:-1}@keyframes l11{to{transform:rotate(calc(var(--s, 1) * 1turn))}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoadingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-loading', imports: [], template: "@if (showLoading) {\n  <div class=\"loading\">\n    <div class=\"loader\"></div>\n  </div>\n}", styles: [".loading{width:100vw;height:100vh;z-index:9999999;position:absolute;background-color:#fffcfccc;display:flex;align-items:center;justify-content:center}.loader{width:50px;aspect-ratio:1;border:2px solid;box-sizing:border-box;border-radius:50%;display:grid;animation:l11 1.5s infinite linear;transform-origin:50% 80%}.loader:before,.loader:after{content:\"\";grid-area:1/1;border:inherit;border-radius:50%;animation:inherit;animation-duration:1s;transform-origin:inherit}.loader:after{--s:-1}@keyframes l11{to{transform:rotate(calc(var(--s, 1) * 1turn))}}\n"] }]
        }], propDecorators: { showLoading: [{
                type: Input
            }] } });

class MobileTreeListComponent {
    translateService;
    platformId;
    nodes = [];
    fields = [];
    loading = false;
    hasMore = false;
    loadMore = new EventEmitter();
    treeAction = new EventEmitter();
    sentinel;
    expanded = new Set();
    observer;
    requesting = false;
    constructor(translateService, platformId) {
        this.translateService = translateService;
        this.platformId = platformId;
    }
    get visibleRows() { return this.flatten(this.nodes); }
    ngOnChanges(changes) { if (changes['loading'] && !this.loading) {
        this.requesting = false;
        if (isPlatformBrowser(this.platformId))
            setTimeout(() => this.requestNext());
    } }
    ngAfterViewInit() { if (!isPlatformBrowser(this.platformId) || !this.sentinel)
        return; this.observer = new IntersectionObserver(e => { if (e.some(x => x.isIntersecting))
        this.requestNext(); }, { rootMargin: '240px 0px' }); this.observer.observe(this.sentinel.nativeElement); }
    ngOnDestroy() { this.observer?.disconnect(); }
    toggle(n) { const k = this.key(n); this.expanded.has(k) ? this.expanded.delete(k) : this.expanded.add(k); }
    isExpanded(n) { return this.expanded.has(this.key(n)); }
    hasChildren(n) { return (n?.children?.length ?? 0) > 0; }
    value(d, f) { return f.split('.').reduce((v, k) => v?.[k], d) ?? ''; }
    emit(data, action) { this.treeAction.emit({ data, action }); }
    requestNext() { if (!isPlatformBrowser(this.platformId) || !window.matchMedia('(max-width: 768px)').matches || this.loading || this.requesting || !this.hasMore)
        return; this.requesting = true; this.loadMore.emit(); }
    flatten(nodes, level = 0) { return nodes.flatMap(n => [{ node: n, level }, ...(this.isExpanded(n) ? this.flatten(n.children ?? [], level + 1) : [])]); }
    key(n) { return n?.data?.id ?? n; }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MobileTreeListComponent, deps: [{ token: TranslateService }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: MobileTreeListComponent, isStandalone: true, selector: "sv-mobile-tree-list", inputs: { nodes: "nodes", fields: "fields", loading: "loading", hasMore: "hasMore" }, outputs: { loadMore: "loadMore", treeAction: "treeAction" }, viewQueries: [{ propertyName: "sentinel", first: true, predicate: ["sentinel"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"mobile-tree\">\n @for(row of visibleRows;track row.node.data.id??$index){\n <article class=\"mobile-tree__card\" [style.--tree-level]=\"row.level\">\n  <button class=\"mobile-tree__toggle\" [class.mobile-tree__toggle--hidden]=\"!hasChildren(row.node)\" type=\"button\" (click)=\"toggle(row.node)\" [attr.aria-expanded]=\"isExpanded(row.node)\"><i class=\"pi\" [class.pi-chevron-down]=\"isExpanded(row.node)\" [class.pi-chevron-right]=\"!isExpanded(row.node)\"></i></button>\n  <div class=\"mobile-tree__fields\">@for(field of fields;track field.field){<div class=\"mobile-tree__field\"><span>{{translateService.translate(field.header)}}</span><strong>{{value(row.node.data,field.field)}}</strong></div>}</div>\n  <div class=\"mobile-tree__actions\"><p-button icon=\"pi pi-plus\" [text]=\"true\" [rounded]=\"true\" (onClick)=\"emit(row.node.data,'add')\"/><p-button icon=\"pi pi-pencil\" [text]=\"true\" [rounded]=\"true\" (onClick)=\"emit(row.node.data,'edit')\"/><p-button icon=\"pi pi-trash\" severity=\"danger\" [text]=\"true\" [rounded]=\"true\" (onClick)=\"emit(row.node.data,'delete')\"/></div>\n </article>\n }@empty{<div class=\"mobile-tree__empty\"><i class=\"pi pi-sitemap\"></i><strong>{{translateService.translate('datatable_empty_title')}}</strong><span>{{translateService.translate('datatable_empty_description')}}</span></div>}\n <div #sentinel class=\"mobile-tree__sentinel\">@if(loading){<i class=\"pi pi-spin pi-spinner\"></i>}</div>\n</div>\n", styles: [":host{display:none}@media(max-width:768px){:host{display:block}.mobile-tree{display:flex;flex-direction:column;gap:.6rem;padding:.75rem}.mobile-tree__card{display:flex;align-items:center;gap:.35rem;margin-left:min(var(--tree-level) * .8rem,3.2rem);padding:.75rem .35rem;border:1px solid var(--p-content-border-color);border-left:3px solid var(--p-primary-color);border-radius:10px;background:var(--p-content-background)}.mobile-tree__toggle{display:grid;place-items:center;flex:0 0 auto;width:1.75rem;height:1.75rem;padding:0;border:0;background:transparent;color:var(--p-primary-color)}.mobile-tree__toggle--hidden{visibility:hidden}.mobile-tree__toggle i{font-size:.7rem}.mobile-tree__fields{display:grid;flex:1;min-width:0;gap:.4rem}.mobile-tree__field{display:flex;min-width:0;flex-direction:column}.mobile-tree__field span{color:var(--p-text-muted-color);font-size:.62rem;font-weight:700;text-transform:uppercase}.mobile-tree__field strong{overflow:hidden;font-size:.82rem;text-overflow:ellipsis;white-space:nowrap}.mobile-tree__actions{display:flex;flex:0 0 auto}:host ::ng-deep .mobile-tree__actions .p-button{width:1.8rem;height:1.8rem;padding:0}.mobile-tree__empty{display:flex;align-items:center;justify-content:center;flex-direction:column;min-height:22rem;gap:.5rem;color:var(--p-text-muted-color)}.mobile-tree__empty i{color:var(--p-primary-color);font-size:2.5rem}.mobile-tree__sentinel{display:flex;align-items:center;justify-content:center;min-height:2.5rem;color:var(--p-primary-color)}}\n"], dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i4.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MobileTreeListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-mobile-tree-list', imports: [ButtonModule], template: "<div class=\"mobile-tree\">\n @for(row of visibleRows;track row.node.data.id??$index){\n <article class=\"mobile-tree__card\" [style.--tree-level]=\"row.level\">\n  <button class=\"mobile-tree__toggle\" [class.mobile-tree__toggle--hidden]=\"!hasChildren(row.node)\" type=\"button\" (click)=\"toggle(row.node)\" [attr.aria-expanded]=\"isExpanded(row.node)\"><i class=\"pi\" [class.pi-chevron-down]=\"isExpanded(row.node)\" [class.pi-chevron-right]=\"!isExpanded(row.node)\"></i></button>\n  <div class=\"mobile-tree__fields\">@for(field of fields;track field.field){<div class=\"mobile-tree__field\"><span>{{translateService.translate(field.header)}}</span><strong>{{value(row.node.data,field.field)}}</strong></div>}</div>\n  <div class=\"mobile-tree__actions\"><p-button icon=\"pi pi-plus\" [text]=\"true\" [rounded]=\"true\" (onClick)=\"emit(row.node.data,'add')\"/><p-button icon=\"pi pi-pencil\" [text]=\"true\" [rounded]=\"true\" (onClick)=\"emit(row.node.data,'edit')\"/><p-button icon=\"pi pi-trash\" severity=\"danger\" [text]=\"true\" [rounded]=\"true\" (onClick)=\"emit(row.node.data,'delete')\"/></div>\n </article>\n }@empty{<div class=\"mobile-tree__empty\"><i class=\"pi pi-sitemap\"></i><strong>{{translateService.translate('datatable_empty_title')}}</strong><span>{{translateService.translate('datatable_empty_description')}}</span></div>}\n <div #sentinel class=\"mobile-tree__sentinel\">@if(loading){<i class=\"pi pi-spin pi-spinner\"></i>}</div>\n</div>\n", styles: [":host{display:none}@media(max-width:768px){:host{display:block}.mobile-tree{display:flex;flex-direction:column;gap:.6rem;padding:.75rem}.mobile-tree__card{display:flex;align-items:center;gap:.35rem;margin-left:min(var(--tree-level) * .8rem,3.2rem);padding:.75rem .35rem;border:1px solid var(--p-content-border-color);border-left:3px solid var(--p-primary-color);border-radius:10px;background:var(--p-content-background)}.mobile-tree__toggle{display:grid;place-items:center;flex:0 0 auto;width:1.75rem;height:1.75rem;padding:0;border:0;background:transparent;color:var(--p-primary-color)}.mobile-tree__toggle--hidden{visibility:hidden}.mobile-tree__toggle i{font-size:.7rem}.mobile-tree__fields{display:grid;flex:1;min-width:0;gap:.4rem}.mobile-tree__field{display:flex;min-width:0;flex-direction:column}.mobile-tree__field span{color:var(--p-text-muted-color);font-size:.62rem;font-weight:700;text-transform:uppercase}.mobile-tree__field strong{overflow:hidden;font-size:.82rem;text-overflow:ellipsis;white-space:nowrap}.mobile-tree__actions{display:flex;flex:0 0 auto}:host ::ng-deep .mobile-tree__actions .p-button{width:1.8rem;height:1.8rem;padding:0}.mobile-tree__empty{display:flex;align-items:center;justify-content:center;flex-direction:column;min-height:22rem;gap:.5rem;color:var(--p-text-muted-color)}.mobile-tree__empty i{color:var(--p-primary-color);font-size:2.5rem}.mobile-tree__sentinel{display:flex;align-items:center;justify-content:center;min-height:2.5rem;color:var(--p-primary-color)}}\n"] }]
        }], ctorParameters: () => [{ type: TranslateService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { nodes: [{
                type: Input
            }], fields: [{
                type: Input
            }], loading: [{
                type: Input
            }], hasMore: [{
                type: Input
            }], loadMore: [{
                type: Output
            }], treeAction: [{
                type: Output
            }], sentinel: [{
                type: ViewChild,
                args: ['sentinel']
            }] } });

class SidebarSubmenuComponent {
    items = [];
    itemSelected = new EventEmitter();
    expanded = new Set();
    get visibleItems() { return this.items.filter(item => item.visible !== false); }
    toggle(id) { this.expanded.has(id) ? this.expanded.delete(id) : this.expanded.add(id); }
    select(event, item) {
        if (item.disabled) {
            event.preventDefault();
            return;
        }
        this.itemSelected.emit(item);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SidebarSubmenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: SidebarSubmenuComponent, isStandalone: true, selector: "sv-sidebar-submenu", inputs: { items: "items" }, outputs: { itemSelected: "itemSelected" }, ngImport: i0, template: `
    <ul class="sv-submenu">
      @for (item of visibleItems; track item.id) {
        <li>
          @if (item.children?.length) {
            <button type="button" class="sv-submenu__item" [disabled]="item.disabled"
                    [attr.aria-expanded]="expanded.has(item.id)" (click)="toggle(item.id)">
              @if (item.icon) { <i [class]="item.icon"></i> }
              <span>{{ item.label }}</span>
              @if (item.badge !== undefined) { <small>{{ item.badge }}</small> }
              <i class="pi" [class.pi-chevron-down]="!expanded.has(item.id)" [class.pi-chevron-up]="expanded.has(item.id)"></i>
            </button>
            @if (expanded.has(item.id)) {
              <sv-sidebar-submenu [items]="item.children ?? []" (itemSelected)="itemSelected.emit($event)" />
            }
          } @else if (item.route) {
            <a class="sv-submenu__item" [routerLink]="item.route" routerLinkActive="active"
               [class.disabled]="item.disabled" (click)="select($event, item)">
              @if (item.icon) { <i [class]="item.icon"></i> }
              <span>{{ item.label }}</span>
              @if (item.badge !== undefined) { <small>{{ item.badge }}</small> }
            </a>
          } @else {
            <button type="button" class="sv-submenu__item" [disabled]="item.disabled" (click)="itemSelected.emit(item)">
              @if (item.icon) { <i [class]="item.icon"></i> }
              <span>{{ item.label }}</span>
            </button>
          }
        </li>
      }
    </ul>
  `, isInline: true, styles: [":host{display:block}.sv-submenu{display:grid;gap:.25rem;margin:0;padding:0;list-style:none}.sv-submenu .sv-submenu{margin-left:1rem;padding-left:.5rem;border-left:1px solid var(--p-content-border-color)}.sv-submenu__item{display:flex;align-items:center;width:100%;gap:.7rem;padding:.7rem .8rem;border:0;border-radius:.65rem;background:transparent;color:var(--p-text-color);text-align:left;text-decoration:none;cursor:pointer}.sv-submenu__item span{flex:1}.sv-submenu__item:hover,.sv-submenu__item.active{background:var(--p-content-hover-background);color:var(--p-primary-color)}.sv-submenu__item.disabled{pointer-events:none;opacity:.5}small{padding:.1rem .4rem;border-radius:999px;background:var(--p-primary-color);color:var(--p-primary-contrast-color)}\n"], dependencies: [{ kind: "component", type: SidebarSubmenuComponent, selector: "sv-sidebar-submenu", inputs: ["items"], outputs: ["itemSelected"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SidebarSubmenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-sidebar-submenu', imports: [CommonModule, RouterLink, RouterLinkActive], template: `
    <ul class="sv-submenu">
      @for (item of visibleItems; track item.id) {
        <li>
          @if (item.children?.length) {
            <button type="button" class="sv-submenu__item" [disabled]="item.disabled"
                    [attr.aria-expanded]="expanded.has(item.id)" (click)="toggle(item.id)">
              @if (item.icon) { <i [class]="item.icon"></i> }
              <span>{{ item.label }}</span>
              @if (item.badge !== undefined) { <small>{{ item.badge }}</small> }
              <i class="pi" [class.pi-chevron-down]="!expanded.has(item.id)" [class.pi-chevron-up]="expanded.has(item.id)"></i>
            </button>
            @if (expanded.has(item.id)) {
              <sv-sidebar-submenu [items]="item.children ?? []" (itemSelected)="itemSelected.emit($event)" />
            }
          } @else if (item.route) {
            <a class="sv-submenu__item" [routerLink]="item.route" routerLinkActive="active"
               [class.disabled]="item.disabled" (click)="select($event, item)">
              @if (item.icon) { <i [class]="item.icon"></i> }
              <span>{{ item.label }}</span>
              @if (item.badge !== undefined) { <small>{{ item.badge }}</small> }
            </a>
          } @else {
            <button type="button" class="sv-submenu__item" [disabled]="item.disabled" (click)="itemSelected.emit(item)">
              @if (item.icon) { <i [class]="item.icon"></i> }
              <span>{{ item.label }}</span>
            </button>
          }
        </li>
      }
    </ul>
  `, styles: [":host{display:block}.sv-submenu{display:grid;gap:.25rem;margin:0;padding:0;list-style:none}.sv-submenu .sv-submenu{margin-left:1rem;padding-left:.5rem;border-left:1px solid var(--p-content-border-color)}.sv-submenu__item{display:flex;align-items:center;width:100%;gap:.7rem;padding:.7rem .8rem;border:0;border-radius:.65rem;background:transparent;color:var(--p-text-color);text-align:left;text-decoration:none;cursor:pointer}.sv-submenu__item span{flex:1}.sv-submenu__item:hover,.sv-submenu__item.active{background:var(--p-content-hover-background);color:var(--p-primary-color)}.sv-submenu__item.disabled{pointer-events:none;opacity:.5}small{padding:.1rem .4rem;border-radius:999px;background:var(--p-primary-color);color:var(--p-primary-contrast-color)}\n"] }]
        }], propDecorators: { items: [{
                type: Input
            }], itemSelected: [{
                type: Output
            }] } });

class SidebarComponent {
    platformId;
    brand = 'Smartverse';
    logoUrl;
    items = [];
    user;
    logoutLabel = 'Sair';
    showLogout = true;
    expanded = true;
    expandedChange = new EventEmitter();
    itemSelected = new EventEmitter();
    logout = new EventEmitter();
    mobile = false;
    constructor(platformId) {
        this.platformId = platformId;
        this.updateViewport();
    }
    updateViewport() {
        if (!isPlatformBrowser(this.platformId))
            return;
        const wasMobile = this.mobile;
        this.mobile = window.innerWidth <= 600;
        if (this.mobile && !wasMobile)
            this.setExpanded(false);
    }
    toggle() { this.setExpanded(!this.expanded); }
    select(item) {
        this.itemSelected.emit(item);
        if (this.mobile)
            this.setExpanded(false);
    }
    setExpanded(value) { this.expanded = value; this.expandedChange.emit(value); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SidebarComponent, deps: [{ token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.23", type: SidebarComponent, isStandalone: true, selector: "sv-sidebar", inputs: { brand: "brand", logoUrl: "logoUrl", items: "items", user: "user", logoutLabel: "logoutLabel", showLogout: "showLogout", expanded: "expanded" }, outputs: { expandedChange: "expandedChange", itemSelected: "itemSelected", logout: "logout" }, host: { listeners: { "window:resize": "updateViewport()" } }, ngImport: i0, template: "<button class=\"sv-sidebar-toggle\" type=\"button\" (click)=\"toggle()\" [attr.aria-expanded]=\"expanded\" aria-label=\"Alternar menu\">\n  <i class=\"pi pi-bars\"></i>\n</button>\n\n<aside class=\"sv-sidebar\" [class.sv-sidebar--open]=\"expanded\" [class.sv-sidebar--mobile]=\"mobile\">\n  <header class=\"sv-sidebar__brand\">\n    @if (logoUrl) { <img [src]=\"logoUrl\" alt=\"\" /> }\n    <strong>{{ brand }}</strong>\n    @if (mobile) {\n      <button type=\"button\" (click)=\"toggle()\" aria-label=\"Fechar menu\"><i class=\"pi pi-times\"></i></button>\n    }\n  </header>\n\n  @if (user) {\n    <section class=\"sv-sidebar__user\">\n      <p-avatar [image]=\"user.imageUrl || undefined\" [label]=\"user.imageUrl ? undefined : (user.initials || user.name.charAt(0))\" shape=\"circle\" />\n      <div><strong>{{ user.name }}</strong>@if (user.subtitle) { <small>{{ user.subtitle }}</small> }</div>\n    </section>\n  }\n\n  <nav aria-label=\"Menu principal\">\n    <sv-sidebar-submenu [items]=\"items\" (itemSelected)=\"select($event)\" />\n  </nav>\n\n  <div class=\"sv-sidebar__footer\">\n    <ng-content select=\"[sidebar-footer]\" />\n    @if (showLogout) {\n      <p-button [text]=\"true\" icon=\"pi pi-sign-out\" [label]=\"logoutLabel\" (onClick)=\"logout.emit()\" />\n    }\n  </div>\n</aside>\n@if (mobile && expanded) { <button class=\"sv-sidebar-backdrop\" type=\"button\" aria-label=\"Fechar menu\" (click)=\"toggle()\"></button> }\n", styles: [":host{display:contents}.sv-sidebar-toggle{position:fixed;top:1rem;left:1rem;z-index:1001;display:none;width:2.5rem;height:2.5rem;border:1px solid var(--p-content-border-color);border-radius:.7rem;background:var(--p-content-background);color:var(--p-text-color)}.sv-sidebar{display:flex;flex-direction:column;width:17rem;height:100dvh;padding:1rem;border-right:1px solid var(--p-content-border-color);background:var(--p-content-background);color:var(--p-text-color)}.sv-sidebar__brand{display:flex;align-items:center;min-height:3rem;gap:.75rem}.sv-sidebar__brand img{max-width:2rem;max-height:2rem}.sv-sidebar__brand strong{flex:1;font-size:1.1rem}.sv-sidebar__brand button{border:0;background:transparent;color:inherit}.sv-sidebar__user{display:flex;align-items:center;gap:.75rem;margin:.75rem 0 1rem;padding:.75rem;border-radius:.75rem;background:var(--p-content-hover-background)}.sv-sidebar__user div{display:grid;min-width:0}.sv-sidebar__user strong,.sv-sidebar__user small{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sv-sidebar__user small{color:var(--p-text-muted-color)}nav{flex:1;overflow:auto}.sv-sidebar__footer{display:grid;gap:.5rem;padding-top:.75rem;border-top:1px solid var(--p-content-border-color)}.sv-sidebar-backdrop{position:fixed;inset:0;z-index:999;border:0;background:#00000073}@media(max-width:600px){.sv-sidebar-toggle{display:grid;place-items:center}.sv-sidebar{position:fixed;inset:0 auto 0 0;z-index:1000;max-width:86vw;transform:translate(-105%);transition:transform .2s ease;box-shadow:0 0 2rem #0003}.sv-sidebar--open{transform:translate(0)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: AvatarModule }, { kind: "component", type: i1$3.Avatar, selector: "p-avatar", inputs: ["label", "icon", "image", "size", "shape", "styleClass", "ariaLabel", "ariaLabelledBy"], outputs: ["onImageError"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i4.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "component", type: SidebarSubmenuComponent, selector: "sv-sidebar-submenu", inputs: ["items"], outputs: ["itemSelected"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sv-sidebar', imports: [CommonModule, AvatarModule, ButtonModule, SidebarSubmenuComponent], template: "<button class=\"sv-sidebar-toggle\" type=\"button\" (click)=\"toggle()\" [attr.aria-expanded]=\"expanded\" aria-label=\"Alternar menu\">\n  <i class=\"pi pi-bars\"></i>\n</button>\n\n<aside class=\"sv-sidebar\" [class.sv-sidebar--open]=\"expanded\" [class.sv-sidebar--mobile]=\"mobile\">\n  <header class=\"sv-sidebar__brand\">\n    @if (logoUrl) { <img [src]=\"logoUrl\" alt=\"\" /> }\n    <strong>{{ brand }}</strong>\n    @if (mobile) {\n      <button type=\"button\" (click)=\"toggle()\" aria-label=\"Fechar menu\"><i class=\"pi pi-times\"></i></button>\n    }\n  </header>\n\n  @if (user) {\n    <section class=\"sv-sidebar__user\">\n      <p-avatar [image]=\"user.imageUrl || undefined\" [label]=\"user.imageUrl ? undefined : (user.initials || user.name.charAt(0))\" shape=\"circle\" />\n      <div><strong>{{ user.name }}</strong>@if (user.subtitle) { <small>{{ user.subtitle }}</small> }</div>\n    </section>\n  }\n\n  <nav aria-label=\"Menu principal\">\n    <sv-sidebar-submenu [items]=\"items\" (itemSelected)=\"select($event)\" />\n  </nav>\n\n  <div class=\"sv-sidebar__footer\">\n    <ng-content select=\"[sidebar-footer]\" />\n    @if (showLogout) {\n      <p-button [text]=\"true\" icon=\"pi pi-sign-out\" [label]=\"logoutLabel\" (onClick)=\"logout.emit()\" />\n    }\n  </div>\n</aside>\n@if (mobile && expanded) { <button class=\"sv-sidebar-backdrop\" type=\"button\" aria-label=\"Fechar menu\" (click)=\"toggle()\"></button> }\n", styles: [":host{display:contents}.sv-sidebar-toggle{position:fixed;top:1rem;left:1rem;z-index:1001;display:none;width:2.5rem;height:2.5rem;border:1px solid var(--p-content-border-color);border-radius:.7rem;background:var(--p-content-background);color:var(--p-text-color)}.sv-sidebar{display:flex;flex-direction:column;width:17rem;height:100dvh;padding:1rem;border-right:1px solid var(--p-content-border-color);background:var(--p-content-background);color:var(--p-text-color)}.sv-sidebar__brand{display:flex;align-items:center;min-height:3rem;gap:.75rem}.sv-sidebar__brand img{max-width:2rem;max-height:2rem}.sv-sidebar__brand strong{flex:1;font-size:1.1rem}.sv-sidebar__brand button{border:0;background:transparent;color:inherit}.sv-sidebar__user{display:flex;align-items:center;gap:.75rem;margin:.75rem 0 1rem;padding:.75rem;border-radius:.75rem;background:var(--p-content-hover-background)}.sv-sidebar__user div{display:grid;min-width:0}.sv-sidebar__user strong,.sv-sidebar__user small{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sv-sidebar__user small{color:var(--p-text-muted-color)}nav{flex:1;overflow:auto}.sv-sidebar__footer{display:grid;gap:.5rem;padding-top:.75rem;border-top:1px solid var(--p-content-border-color)}.sv-sidebar-backdrop{position:fixed;inset:0;z-index:999;border:0;background:#00000073}@media(max-width:600px){.sv-sidebar-toggle{display:grid;place-items:center}.sv-sidebar{position:fixed;inset:0 auto 0 0;z-index:1000;max-width:86vw;transform:translate(-105%);transition:transform .2s ease;box-shadow:0 0 2rem #0003}.sv-sidebar--open{transform:translate(0)}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { brand: [{
                type: Input
            }], logoUrl: [{
                type: Input
            }], items: [{
                type: Input
            }], user: [{
                type: Input
            }], logoutLabel: [{
                type: Input
            }], showLogout: [{
                type: Input
            }], expanded: [{
                type: Input
            }], expandedChange: [{
                type: Output
            }], itemSelected: [{
                type: Output
            }], logout: [{
                type: Output
            }], updateViewport: [{
                type: HostListener,
                args: ['window:resize']
            }] } });

const COMPONENTS = [AccountBalancesComponent, DatatableComponent, AutoCompleteComponent, DropdownComponent,
    ImageUploadComponent, InputDateComponent, InputMaskComponent, InputNumberComponent, InputTextComponent,
    MultiSelectComponent, LoadingComponent, MobileTreeListComponent, ScreenReportButtonComponent, SidebarComponent];
class SmartverseComponentsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartverseComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SmartverseComponentsModule, imports: [AccountBalancesComponent, DatatableComponent, AutoCompleteComponent, DropdownComponent,
            ImageUploadComponent, InputDateComponent, InputMaskComponent, InputNumberComponent, InputTextComponent,
            MultiSelectComponent, LoadingComponent, MobileTreeListComponent, ScreenReportButtonComponent, SidebarComponent], exports: [AccountBalancesComponent, DatatableComponent, AutoCompleteComponent, DropdownComponent,
            ImageUploadComponent, InputDateComponent, InputMaskComponent, InputNumberComponent, InputTextComponent,
            MultiSelectComponent, LoadingComponent, MobileTreeListComponent, ScreenReportButtonComponent, SidebarComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartverseComponentsModule, imports: [AccountBalancesComponent, DatatableComponent, AutoCompleteComponent, DropdownComponent,
            ImageUploadComponent, InputDateComponent, InputMaskComponent, InputNumberComponent, InputTextComponent,
            MultiSelectComponent, MobileTreeListComponent, ScreenReportButtonComponent, SidebarComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartverseComponentsModule, decorators: [{
            type: NgModule,
            args: [{ imports: COMPONENTS, exports: COMPONENTS }]
        }] });

class BaseComponent {
    showLoading = false;
    onShowLoading() { this.showLoading = !this.showLoading; }
    onValidator(form) { return form.valid; }
}

class Fields {
    name = "";
    label = "";
    type;
    size = 0;
    hidden = false;
    order = 0;
    guidance = "";
    validators;
    required;
    /**
     * Propriedade para definir se o campo será visivel e dispoibiliczado para filtragem dos dados
     */
    enableFieldsFilter = false;
    /*
        Usado quando a tela possui abas, usa-se o reference para indicar a qual aba pertenci o field
    */
    reference;
}

class FieldsForm {
    /**
     * Campos do formulario, não é necessário preencher, será preenchido automaticamente
     */
    fields;
    /**
     * Form Group, não é necessário preencher
     */
    formgroup;
}

class PostalCodeService {
    http;
    config;
    constructor(http, config) {
        this.http = http;
        this.config = config;
    }
    lookup(postalCode) {
        return this.http.get(this.config.endpoints.postalCode, { params: new HttpParams().set('postalCode', postalCode) });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PostalCodeService, deps: [{ token: i1$1.HttpClient }, { token: SMARTVERSE_COMPONENTS_CONFIG }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PostalCodeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PostalCodeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [SMARTVERSE_COMPONENTS_CONFIG]
                }] }] });

class ModalService {
    dialogs;
    constructor(dialogs) {
        this.dialogs = dialogs;
    }
    open(config) {
        return this.dialogs.open(config.component, { header: config.header, width: config.width ?? '80vw', modal: true,
            draggable: true, maximizable: false, data: config.data, baseZIndex: 999999 });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalService, deps: [{ token: i1$4.DialogService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ModalService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$4.DialogService }] });

class ThemeService {
    document;
    constructor(document) {
        this.document = document;
    }
    setDarkMode(enabled) { this.document.documentElement.classList.toggle('app-dark', enabled); }
    onConfigurationTheme(theme) { this.setDarkMode(theme.toLowerCase().includes('dark')); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ThemeService, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

function collectCodes(items) {
    const codes = [];
    for (const item of items ?? []) {
        if (item?.codeTree !== null && item?.codeTree !== undefined) {
            codes.push(String(item.codeTree).trim());
        }
        if (Array.isArray(item?.children)) {
            codes.push(...collectCodes(item.children));
        }
    }
    return codes;
}
function getNextTreeCode(items, parentCode) {
    const parentParts = parentCode
        ? String(parentCode).split(".").filter(Boolean)
        : [];
    const siblingNumbers = collectCodes(items)
        .map(code => code.split(".").filter(Boolean))
        .filter(parts => {
        if (parentParts.length === 0) {
            return parts.length === 1;
        }
        return parts.length === parentParts.length + 1
            && parentParts.every((part, index) => parts[index] === part);
    })
        .map(parts => Number(parts[parts.length - 1]))
        .filter(value => Number.isInteger(value) && value >= 0);
    const nextNumber = (siblingNumbers.length ? Math.max(...siblingNumbers) : 0) + 1;
    return parentParts.length ? `${parentParts.join(".")}.${nextNumber}` : String(nextNumber);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AccountBalancesComponent, Action, AppControlValueAccessor, AutoCompleteComponent, BaseComponent, Column, CrudService, DEFAULT_SMARTVERSE_COMPONENTS_CONFIG, DataTable, DatatableComponent, DropdownComponent, Fields, FieldsForm, FieldsService, Filters, ImageUploadComponent, ImageUploadService, InputDateComponent, InputMaskComponent, InputNumberComponent, InputTextComponent, LoadingComponent, MobileTreeListComponent, ModalService, MultiSelectComponent, PostalCodeService, RequestData, SMARTVERSE_COMPONENTS_CONFIG, SMARTVERSE_TRANSLATION_OVERRIDES, ScreenReportButtonComponent, ScreenReportService, SidebarComponent, SidebarSubmenuComponent, SmartverseComponentsModule, ThemeService, ToastService, TranslateService, base64ToArrayBuffer, generateUUIDv4, getNextTreeCode, provideSmartverseComponents };
//# sourceMappingURL=smartverse-components.mjs.map
